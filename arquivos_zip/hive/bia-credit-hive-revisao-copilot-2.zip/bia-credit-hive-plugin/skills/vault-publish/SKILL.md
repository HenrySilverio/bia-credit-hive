---
name: vault-publish
description: "Knowledge Vault, phase 3: validates with the catalog's rules and the Hive's stricter ones, publishes the notes into the tribe's Vault clone with indexes and log, and hands the pull request to the developer. Runs in the bchive-vault agent."
argument-hint: "<extraction-id> [vault: <clone folder>] | checar <clone> | confirmar <note>"
disable-model-invocation: true
---
# /bia-credit-hive:vault-publish

If the instructions of this chat do not start with `# Agent bchive-vault`, do not read or run anything. Answer in
one line, in Brazilian Portuguese: select the `bchive-vault` agent in a new chat and send the same request.

## Publish an extraction

1. Clone: `vault:` in the message, or `vault.clone` in `.bchive/bchive.json`. Neither: ask the developer
   for the folder of their clone of the Vault repository and stop. The clone must be on its default branch and
   up to date (`git -C <clone> pull`): ask the developer to do it.
2. Run `node .bchive/bin/okf.mjs publicar <id> --vault <clone>`. It applies the notes, the indexes and the
   log in a copy, checks the catalog's rules (the Vault's CI) and the Hive's, and only then writes to the clone.
   Any ERRO: nothing was written; fix the drafts (phase 2) and run again. The notes go to the squad of the
   approved plan. A note already published with the same extracted content stays as it is, with its status and
   confirmation; a note whose content changed goes back to `draft`, without `verified`.
3. Show the Git Bash commands it printed. The developer creates the branch, commits and opens the pull request
   (title in English, `feat:` for new notes, `fix:` for corrections). A colleague from the unit's teams approves;
   nobody approves their own. Never run Git yourself.
4. Say that the notes go as `draft`, without `verified`.

## Check a Vault clone

`node .bchive/bin/okf.mjs checar-vault <clone>`: both layers on the clone as it is, including notes that
did not come from the Hive (for those, only the content rules). Show the errors grouped by note.

## Confirm a note (human gate)

Whoever checked the note against its source runs, in their own Git Bash:

    node .bchive/bin/okf.mjs confirmar <clone>/vault/<path>.md --por <login>

It records `verified` (a list, as in OKF 0.2), moves the note to `stable` and writes the log. Never run it.
Confirming is by role: the PM for `Business Rule`, `Behavior` and `Decision`; the tech lead for `Architecture`,
`Coding Standard` and `Dependency Baseline`. The commit is `fix: confirm <note>`.
