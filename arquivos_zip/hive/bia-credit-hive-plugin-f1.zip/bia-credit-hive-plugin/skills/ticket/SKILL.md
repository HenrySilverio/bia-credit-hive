---
name: ticket
description: "Shows or pins the Jira ticket used to tie usage to the task."
argument-hint: "[KEY-123 | --limpar]"
disable-model-invocation: true
---
# /bia-credit-hive:ticket

Utility: runs in any agent with a terminal.

Run `node .bchive/bin/bchive.mjs ticket` with the received argument, unchanged, and show the output. With
no argument it only shows the current ticket and where it came from: pinned, proposal or branch name.
