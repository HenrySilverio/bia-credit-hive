---
name: vault-plan
description: "Knowledge Vault, phase 1: inventory of the code and the extraction plan in slices, each under a token ceiling. Runs in the bchive-vault agent."
argument-hint: "<folder...> [squad: <squad>] [id: <extraction-id>]"
disable-model-invocation: true
---
# /bia-credit-hive:vault-plan

If the instructions of this chat do not start with `# Agent bchive-vault`, do not read or run anything. Answer in
one line, in Brazilian Portuguese: select the `bchive-vault` agent in a new chat and send the same request.

## Step 1 - Scope

- Folders: what came after the command. Nothing: ask which folders (one module is a good first extraction) and stop.
- Squad: `squad:` in the message, or `vault.squad` in `.bchive/bchive.json`. Neither: ask and stop.
- Id: `id:` in the message, or the first folder in kebab-case.

## Step 2 - Inventory

Run `node .bchive/bin/okf.mjs inventario <id> --escopo <folder...>`. Show the developer the totals, the
modules and what was left out. Never read the code files yourself.

## Step 3 - Plan

Write `.bchive/vault/<id>/plano.json`, using only `inventario.json`:

```json
{ "squad": "<squad>",
  "diretorios": { "<theme>": "<one sentence: what the folder holds>" },
  "fatias": [ { "nn": "01", "titulo": "<slice>", "arquivos": ["<path>", "<path>#L1-L400"],
                "notas": [ { "caminho": "<theme>/<note>.md", "tipo": "Business Rule", "titulo": "<title>", "foco": "<what to look for>" } ] } ] }
```

- One slice per module of the inventory; a module with parts becomes slices with line ranges.
- One note per capability, with its rules as sections. Not one note per rule: the whole tribe has 1,000 files.
- `tipo`: `Architecture` (includes layer rules), `Coding Standard`, `Business Rule`, `Behavior`,
  `Dependency Baseline` (only from the dependency files, only what the team must keep), `Glossary`, `Decision`.
- `caminho`: relative to the squad folder, lowercase kebab-case, no accents; `index.md` and `log.md` are reserved.
- A note belongs to one slice. Notes that several slices feed are merged in phase 2.

Run `node .bchive/bin/okf.mjs plano <id>` (add `--vault <clone>` to check the Vault budget). Fix every
ERRO and run again.

## Step 4 - Human gate

Show the plan as a short table (slice, tokens, notes) and the command the developer runs in their own Git Bash:

    node .bchive/bin/okf.mjs aprovar-plano <id> --por <login>

Never run it. Next step after approval: `/bia-credit-hive:vault-extract <id>`. Stop.
