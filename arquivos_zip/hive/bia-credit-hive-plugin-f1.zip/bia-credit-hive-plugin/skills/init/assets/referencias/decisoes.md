# Decisions

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Contract of the `.bchive/decisoes/` layer. Read on demand, whenever `design.md` exists or is being
written. The three tests that separate a durable decision from a local one are in the contract, section 6,
because they trigger rigor; this file covers format and mechanics.

## Why this layer exists

`specs/` records what the system does. Nothing records why it does it that way. Without this layer, the
reason for a decision lives in `design.md`, which belongs to one change and goes whole to `archive/`. Six
months later, "why does the BFF normalize here and not the MFE?" can only be answered by reading forty
archived folders. In practice nobody does: the discarded alternative comes back as a new proposal, and
someone implements it.

An architectural decision lives longer than the change that produced it, and differently from the spec. A
spec changes when behavior changes. A decision changes when someone replaces it, which is rare and is
exactly the event that must be recorded.

## Examples of the boundary

**Not in:** choosing between two equivalent libraries; a variable or file name; execution order with no
external consequence; anything an afternoon refactor undoes.

**In:** the format of an identifier exposed in a contract; where data normalization happens between
layers; the consistency model between two services; what is stored versus recomputed; keeping
compatibility with a specific consumer.

## Marking in design.md

Marking happens in planning, on an expensive model, while the judgment about the decision is being made
anyway. Promotion happens at archive, on a cheap model, mechanically.

Only a decision marked `permanente` is promoted. Every permanent decision needs the four parts of the
template (the constraint that forced it, the chosen option, the discarded alternatives with their reason,
the accepted consequence) and the `Capacidades` line, because that content is copied with no additions.

## Record format

`.bchive/decisoes/DEC-<number>-<slug>.md`, with a three-digit sequential number, global and never
reused. Kebab-case slug, at most four words, naming the subject of the decision. Written in Brazilian
Portuguese.

| Field | Content |
| --- | --- |
| Data | archive date, YYYY-MM-DD |
| Mudança | the change-id that produced the decision |
| Estado | `vigente` or `substituída por DEC-<number>` |
| Capacidades | copied from the decision's `Capacidades` field in `design.md` |

The body is the text of the four parts, copied literally from `design.md`. No rewriting, no summary, no
style adjustment.

`.bchive/decisoes/index.md` has one line per decision: identifier, title, state and path. A replaced
decision stays in the index, marked: deleting the record deletes the reason the replacement happened.

## Replacement

A new decision that contradicts one in force declares it in `design.md`, in the decision itself, with the
line `Substitui: DEC-<number>`. When applied, the old record's `Estado` becomes `substituída por
DEC-<new>`, and the new one starts with `Estado: vigente`. The old text is never edited.

If the `Substitui:` target does not exist in `decisoes/`, it is an error, not a warning: stop before
writing any file. Same rule as the deltas: the marking was written against a state that already changed.

## Where each phase comes in

| Phase | Role in the decisions layer |
| --- | --- |
| plan | reads the index, declares conflicts with decisions in force, marks `Durabilidade` on each decision |
| implement | does not touch `decisoes/` nor read the index |
| review | checks the marking, the four parts and the `Substitui:` target |
| archive | promotes permanent decisions, updates states and the index |

Reading the whole `decisoes/` is a token-economy regression. Read the index, decide which decision the
change touches, read only that one. Implement stays out on purpose: if the implementation could record a
decision, it would stop being a prior agreement and become a justification of what was done.
