# Project map

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Query reference. Read it before the first query of the session.

## What it is for

Three questions, before opening a file: what already exists to reuse, where it is, and what breaks if I
touch it here. Text search answers the first one badly and the other two not at all.

## How to query

```
node .bchive/bin/bchivemap.mjs query "<terms>"           matching nodes and their neighbors
node .bchive/bin/bchivemap.mjs explain <symbol|file>     where it is, what it uses, who uses it
node .bchive/bin/bchivemap.mjs affected <files...>       who depends on what will change
node .bchive/bin/bchivemap.mjs path <A> <B>              how A reaches B
node .bchive/bin/bchivemap.mjs resumo                    what exists, per folder
```

Every output is cut at 2,000 characters (`--budget <n>` for more). Before answering, the map checks file
hashes and re-extracts only what changed: it is always in sync with the working tree.

## How to read the answer

- `EXTRACTED`: read directly from the code or the compiler. Trust it.
- `INFERRED`: resolved by name, framework pattern or endpoint path. Check the code before stating it.
- `AMBÍGUO`: the file has a link no static analysis resolves (DI token by string, reflection, event,
  dynamic call). Read the code there.
- No result: the map does not know. Only then, text search.

Layers: L1 regex in any language; L2 the project's TypeScript compiler and the JDK's `jdeps`, when
present; L3 lazy routes, Native Federation remotes, Spring endpoints and OpenAPI, front-end HTTP calls.
`bchivemap.mjs status` says which are active. If the repository has `graphify-out/graph.json`, the map
uses the Graphify graph as is.

## Use per phase

- **Plan**: `resumo` and `query` to write `Toca:` and `## Ponteiros` with real paths; `affected` to size
  the slice and find callers the briefing did not list.
- **Implementer**: `explain` before creating anything new: the first rung is reuse.
- **On-call**: `affected` comes in the package.
- **Archive**: `affected` over the diff files for the impact radius in `resumo.md`.

Never read `.bchive/mapa/graph.json` or `cache.json`: it is script input, and costs the whole
repository in tokens.
