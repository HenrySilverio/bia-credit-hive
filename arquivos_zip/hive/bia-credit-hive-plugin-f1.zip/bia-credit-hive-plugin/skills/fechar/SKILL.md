---
name: fechar
description: "Shortcut for /bia-credit-hive:fechar. The phase runs in the bchive-archive agent."
argument-hint: "<archived folder> <PR number>"
disable-model-invocation: true
---
# /bia-credit-hive:fechar

This phase runs in the `bchive-archive` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent bchive-archive`, follow them with the text that came after the
command, preceded by `fechar`, and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `bchive-archive` agent
in the agent picker, in a new chat, and send the same request starting with `fechar`. Running the phase
outside its agent skips the contract and grants tools it should not have.
