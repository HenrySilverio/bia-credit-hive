---
name: lembrar
description: "Turns something the team learned while using the flow into a lesson proposal (a rule, a process step or a term) that a person approves and that is versioned in conhecimento/licoes/. Runs in any agent with a terminal."
argument-hint: "<what should be remembered, in one or two sentences>"
disable-model-invocation: true
---
# /bia-credit-hive:lembrar

Write a **lesson proposal** from the developer's message. You never approve it: a person does, in their own
terminal, and only then it becomes a versioned file that the agents read for the paths it covers. Reply in
Brazilian Portuguese; the lesson itself is written in Brazilian Portuguese.

Utility: runs in any agent with a terminal.

## Step 1 - Is it a lesson?

A lesson is something that will happen again: a code rule the review keeps catching, a process step people
forget, a domain term. Not a lesson: a fact about this change only, a personal preference (that belongs to
the developer's own instructions or to Copilot Memory), or anything the linter already enforces. If it is not
a lesson, say so in one line and stop.

Before writing, run `node .bchive/bin/bchive.mjs licoes para <the paths it is about>` and
`node .bchive/bin/bchive.mjs licoes propostas`: if an approved lesson or an open proposal already says it,
point to it and stop.

## Step 2 - Draft

Decide, and ask only what you cannot decide:

- `--tipo`: `regra` (checkable by reading a diff), `processo` (how the team works) or `termo` (vocabulary).
- `--escopo`: the narrowest glob that covers it (`src/app/feature/**`, `bff/src/main/java/**`), or `*` only when
  it truly applies to the whole repository. A wide scope costs tokens in every task.
- `--titulo`: the rule in one line, imperative. `--texto`: what to do, verifiable. `--porque`: the concrete case
  that taught it. Up to 700 characters in total.
- `--origem`: the change-id or the verdict file it came from, when there is one.

Run `node .bchive/bin/bchive.mjs licoes propor --titulo "..." --texto "..." --porque "..." --tipo <tipo> --escopo "<globs>" --origem <origem>`.

## Output

Up to five lines: the proposal id, the lesson as written, and the command for whoever approves it (tech lead
or the developer), printed by the script. Never run `licoes aprovar`: the hook denies it.
