---
name: plan
description: "Shortcut for /bia-credit-hive:plan. The phase runs in the bchive-plan agent."
argument-hint: "<briefing.md path> [replanejar: <change-id>] [rigor: lite]"
disable-model-invocation: true
---
# /bia-credit-hive:plan

This phase runs in the `bchive-plan` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent bchive-plan`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `bchive-plan` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
