---
name: implement
description: "Shortcut for /bia-credit-hive:implement. The phase runs in the bchive-implement agent."
argument-hint: "<change-id> [N fatias | paralelo]"
disable-model-invocation: true
---
# /bia-credit-hive:implement

This phase runs in the `bchive-implement` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent bchive-implement`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `bchive-implement` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
