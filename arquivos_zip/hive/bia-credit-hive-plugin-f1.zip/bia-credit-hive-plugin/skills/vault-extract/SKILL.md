---
name: vault-extract
description: "Knowledge Vault, phase 2: one clean subagent per slice writes the draft notes, the coordinator consolidates from the summaries, and an isolated reviewer checks each note against the cited lines. Runs in the bchive-vault agent."
argument-hint: "<extraction-id> [N fatias]"
disable-model-invocation: true
---
# /bia-credit-hive:vault-extract

If the instructions of this chat do not start with `# Agent bchive-vault`, do not read or run anything. Answer in
one line, in Brazilian Portuguese: select the `bchive-vault` agent in a new chat and send the same request.

## Step 1 - State

Run `node .bchive/bin/okf.mjs estado <id>`. Plan not approved: show the approval command for the
developer and stop.

## Step 2 - Slices, one at a time

For each pending slice (default: all, in order; "N fatias": the next N):

1. `node .bchive/bin/okf.mjs pacote <id> <NN>`.
2. Call `bia-credit-hive:bchive-vault-extrator` with the literal prompt the command printed, nothing added.
3. `node .bchive/bin/okf.mjs concluir <id> <NN>`. ERRO: call the extractor again with the same literal
   prompt plus one line, "Fix: " and the errors as printed; at most two rounds, then stop and report.

Never read the package or the code yourself: your context holds the summaries, not the code.

## Step 3 - Consolidate

Read only `.bchive/vault/<id>/resumos/*.md` and the frontmatter of the drafts. Then, editing only drafts:
- Notes on the same capability from different slices: merge into one, keeping every footnote and source.
- Add relative Markdown links between related notes ("## Relacionadas").
- A term used by several notes: one `Glossary` note.
Run `node .bchive/bin/okf.mjs checar <id>` until it has no ERRO.

## Step 4 - Isolated review

Run `node .bchive/bin/okf.mjs revisao <id>`. For each prompt it printed, call `bia-credit-hive:bchive-vault-revisor`
with that literal prompt. REPROVADO: send the note back to the extractor with the findings (same rule as step 2,
item 3), then run `revisao` again. Never edit a verdict.

When every note is APROVADO: next step `/bia-credit-hive:vault-publish <id>`. Stop.
