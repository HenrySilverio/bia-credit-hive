---
name: squad-audit
description: "Audits the developer's Copilot customization (AGENTS.md, instructions, agents, skills, prompts, hooks, in the repository, the user folder and installed plugins) and the flow configuration: verbosity, ambiguity, conflicts, gaps and risks, with concrete rewrites. Read-only. Runs in the bchive agent."
argument-hint: "[--so-repositorio]"
disable-model-invocation: true
---
# /bia-credit-hive:squad-audit

Review the quality of the developer's harness and write a report with what to cut, what to clarify, what is
missing and what is risky. You never edit the developer's files: you propose, they decide. Reply and write
the report in Brazilian Portuguese.

Runs in the `bchive` agent. If the instructions of this chat do not start with the line `# Agent bchive`, do not
read or run anything: answer in one line that they should select the `bchive` agent in a new chat and send
`/bia-credit-hive:squad-audit` again.

## Step 1 - Mechanical part (script)

Run `node .bchive/bin/bchive.mjs squad-audit --usuario` (with `--so-repositorio` in the request, drop
`--usuario`). Show the summary it prints. It only reads files: repository (`AGENTS.md`, `.github/`), user
folder (`~/.copilot/`, VS Code profile prompts) and installed plugins (agents and skills only).

## Step 2 - Read only what the script separated

Read `inventario.md` and `trechos.md` from the folder it printed. Open a whole file only when a passage is
not enough to judge, and at most three files. Never open the installed plugins' files: they are not the
developer's to change.

## Step 3 - Judge

Judge for effect on the result and on tokens, never for taste. For each point, cite file and line.

1. **Verbosity**: text that does not change what the model does: history and motivation without a rule,
   long examples where one line would do, the same rule in two files, what the linter or compiler already
   enforces, generic advice the model already follows ("write clean code"), always-loaded text that only one
   folder needs (move it to an instruction with a narrow `applyTo`).
2. **Ambiguity**: every vague term the script marked, in context; a rule with two readings; a rule without
   scope (which folder, layer, file type); two files that disagree (use the "Tópicos" section: same subject,
   different files).
3. **Missing for a better delivery**, judged against the stack the files themselves mention: where tests
   live and which runner; layer boundaries; how each layer consumes its own contract (each layer keeps and
   generates from its own copy of the OpenAPI, never a shared global artifact); error handling;
   accessibility; design system usage; an instruction without `applyTo` or `description`.
4. **Harness risks**: hooks (relative path, no `exit 0`, no `powershell` variant), agents with all tools or
   with keys the Copilot harness rejects, duplicated agent names, leftovers of an old installation, an
   executor that cannot be called as a subagent.
5. **Coexistence with the flow**: rules that tell agents to commit, push, open PRs, fix the reply language or
   write into `.bchive/`. They do not block the flow (it wins on process), but they cost tokens and
   confuse the developer's own agents.

Do not recommend versioning anything in `.github/`, and do not recommend a single big
`copilot-instructions.md`: prefer small `.instructions.md` files with a narrow `applyTo` and a clear
`description`.

## Step 4 - Report

Write `relatorio.md` in the same folder:

- `# Auditoria do harness · <data>`, then two lines: estimated fixed cost per request and counts.
- `## Faça primeiro`: up to five actions, ordered by effect (tokens saved per request, or wrong result
  avoided).
- `## Por arquivo`: for each file with something to say, items tagged `[corrigir]`, `[melhorar]` or
  `[opcional]`, each with: `arquivo:linha`, the problem, why it hurts, and the proposal as
  `Antes:` / `Depois:` with the exact text. A cut is `Depois: (remover)`.
- `## O que falta`: rules worth writing, each with the target file and `applyTo`.
- `## Executores`: per external agent, ready or what to change (from the script's `executor` findings).
- `## Lições`: expired lessons the script listed, if any, with the question for the team: confirm or remove.

Every number in the report comes from the script (tokens are its estimate). Do not invent counts.

## Output

Up to twelve lines in the chat: the fixed cost, the five actions, and the report path. Offer to show the
`Antes`/`Depois` of a specific file; applying it is the developer's call, in their own editor.
