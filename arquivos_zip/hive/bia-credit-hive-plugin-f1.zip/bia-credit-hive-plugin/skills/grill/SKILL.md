---
name: grill
description: "Interviews a raw need until it becomes a briefing and updates the glossary. Runs in the bchive-discovery agent."
argument-hint: "<the need in one or two sentences>"
disable-model-invocation: true
---
# /bia-credit-hive:grill

Turn a pain into a briefing, by asking. Nothing is inferred. Interview and write in Brazilian Portuguese.

Runs in the `bchive-discovery` agent. If the instructions of this chat do not start with the line
`# Agent bchive-discovery`, do not read or run anything: answer in one line that they should select the
`bchive-discovery` agent in a new chat and send `/bia-credit-hive:grill` again.

## Inputs

The **need** is the developer's first message in this chat. The following ones are the round answers: this
session is the whole interview, from start to save.

## Step 0 - Contract

Read `.bchive/referencias/contrato.md`, sections 1, 3 and 4.

Empty need: ask what is bothering them today and stop. Do not offer an example: an offered example becomes
the answer.

This agent has no search tool, on purpose, and does not read code. The current state is a question for the
human.

## Step 1 - Prepare

Read `.bchive/referencias/tecnica-grilling.md` and `.bchive/glossario.md`. Build the frontier: the
questions whose prerequisites are already answered. Drop what the need already answered.

## Step 2 - Conduct

At most four rounds, five questions each (contract section 4).

- In the first round, ask for the Jira key (e.g. `GPCNLS-10019`) if it did not come with the need. It goes to
  `Prazo e ticket` and to the folder name. It is mandatory: without it nothing is saved. With no open
  ticket, tell the developer to open one and stop.
- An ambiguous domain term, or one with two names, becomes a question. Resolved, note the term and the
  definition for the glossary.
- A vague answer is a gap, not an answer. Vague again: classify it as blocking or edge.

End before the limit in the cases of contract section 4.

## Step 3 - Inputs

Read the Insumos section of `.bchive/referencias/molde-briefing.md`. With the problem and the expected
result understood, spend one round on the inputs: for each of the eight, decide with the developer whether
it applies. For each one that applies and did not come, **ask** for it, saying what and in which form. Do
not assume content, do not invent field names:

- **Telas**: the Figma links and the analysis. If the developer has no analysis, give them this request for
  a chat with the team's Figma agent (or a design-to-code agent) and ask them to save the answer as
  `figma.md` in the briefing folder: "Só análise, sem gerar código. Para cada node: componentes do design
  system, estados (habilitado, desabilitado, erro, vazio, carregando), textos exatos, tokens e o
  comportamento de cada interação."
- **Contrato de API**: the path of the type or OpenAPI the MFE consumes and of the contract the BFF exposes,
  each layer its own. A file the developer points to is delivered material: read it to transcribe field
  names with exact spelling, with origin. Do not search for others.
- **Exemplos**: at least one case with real values.
- **Regras e limites, estados e erros, configuração, dependências**: ask what is missing; what does not
  apply gets the reason.

The developer does not have the input now: save it as `pendente`, with who provides it. The briefing is
saved, but the plan does not start until the input arrives; say so in the output.

## Step 4 - Save

Read `.bchive/referencias/molde-briefing.md` and save
`.bchive/briefings/<TICKET>-<subject>/briefing.md`, in the template, with the gap and origin conventions.

Append the new terms to the end of the table in `.bchive/glossario.md`. Do not rewrite an existing line
unless the developer asks.

Before saving, check the briefing gates of contract section 4, especially: every line traces to an answer
in this conversation, and no section contains an acceptance criterion.

## Output

The template's output format, plus one line with the terms added to the glossary, one with the inputs (ok,
não se aplica, pendente) and the next action: with a pending input, what is missing and who provides it;
with none, in a new chat, agent `bchive-plan`, `/bia-credit-hive:plan <briefing path>`.
