---
name: uso
description: "Usage and adoption report of b.IA Credit Hive and of Copilot chats on this machine: sessions, agent and subagent turns, commands, time and tokens. Never money or prompt content."
argument-hint: "[relatorio [--de AAAA-MM-DD] [--ate AAAA-MM-DD] | resumo <change> | exportar | verificar-selos]"
disable-model-invocation: true
---
# /bia-credit-hive:uso

Utility: runs in any agent with a terminal. Reply in Brazilian Portuguese.

- No argument, or `relatorio`: run `node .bchive/bin/uso.mjs importar`, then
  `node .bchive/bin/uso.mjs relatorio` with the received arguments, and show the output.
- `resumo <change or archived folder>`: run `node .bchive/bin/uso.mjs resumo <arg>` and show it.
- `exportar`: run `node .bchive/bin/uso.mjs exportar` with the received arguments and say the path of the
  JSON. It is the input of the future upload; nothing is sent anywhere.
- `verificar-selos`: run `node .bchive/bin/uso.mjs verificar-selos` and show the output.

Do not interpret the numbers beyond what the output shows. No token value comes from you. There is no money,
credit or model price in this report, and you never estimate one.
