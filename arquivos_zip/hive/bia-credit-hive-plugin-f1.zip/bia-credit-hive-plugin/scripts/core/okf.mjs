#!/usr/bin/env node
// b.IA Credit Hive - extrator do Vault de conhecimento (OKF 0.2). Sem dependência, Node LTS 22 ou 24.
//
// Extrai do código o que é conhecimento (arquitetura e camadas, padrões, regras de negócio, comportamento,
// versões recomendadas, glossário, decisões), em fatias com teto de tokens, e publica no clone do Vault da tribo.
// Nenhum código vai para o Vault. Rascunhos e estado ficam em .bchive/vault/<extracao>/ (nunca versionado).
//
//   node .bchive/bin/okf.mjs inventario <extracao> [--escopo <pasta>...] [--teto <tokens>]
//   node .bchive/bin/okf.mjs plano <extracao>                   confere plano.json (o agente escreve)
//   node .bchive/bin/okf.mjs aprovar-plano <extracao> --por <login>   portão humano
//   node .bchive/bin/okf.mjs pacote <extracao> <NN>             pacote da fatia para o subagente extrator
//   node .bchive/bin/okf.mjs concluir <extracao> <NN>           normaliza e confere os rascunhos da fatia
//   node .bchive/bin/okf.mjs revisao <extracao>                 pacotes de revisão (nota + linhas citadas)
//   node .bchive/bin/okf.mjs estado [<extracao>]
//   node .bchive/bin/okf.mjs checar <extracao>                  camada do Hive nos rascunhos
//   node .bchive/bin/okf.mjs checar-vault <clone>               as duas camadas no clone do Vault, como está
//   node .bchive/bin/okf.mjs publicar <extracao> --vault <clone> [--squad <squad>]
//   node .bchive/bin/okf.mjs confirmar <nota no clone> --por <login>  portão humano: grava verified

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, cpSync } from 'node:fs';
import { join, dirname, resolve, relative, basename } from 'node:path';
import { posix } from 'node:path';
import { createHash } from 'node:crypto';
import { HW, sair, barra, config, lerJson, gravarJson, git, raizGit, headCurto, excluirPathspec, problemaNode, PLUGIN_PADRAO } from './lib/comum.mjs';
import {
  TIPOS, SEGMENTO, ARQUIVO_NOTA, LOGIN, normalizarRascunho, checarNota, checarCatalogo, ehCloneDoVault, orcamento, notasDoVault,
  copiaTemporaria, indexarNota, registrarNoLog, lerNota, renderizarFrontmatter,
} from './lib/okf.mjs';

const pn = problemaNode();
if (pn) console.error(`AVISO ${pn.texto}`);

const argv = process.argv.slice(2);
const cmd = argv[0];
const pos = []; const op = {};
for (let i = 1; i < argv.length; i++) {
  const a = argv[i];
  if (a.startsWith('--')) {
    const k = a.slice(2);
    if (k === 'escopo') { op.escopo = op.escopo || []; while (argv[i + 1] && !argv[i + 1].startsWith('--')) op.escopo.push(argv[++i]); } else if (argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) op[k] = argv[++i]; else op[k] = true;
  } else pos.push(a);
}

const RAIZ = process.cwd();
const precisaRepo = !['checar-vault', 'confirmar'].includes(cmd);
if (precisaRepo && cmd && !existsSync(join(RAIZ, HW))) sair(2, `${HW}/ não existe aqui: rode da raiz do repositório preparado pelo init.`);
const cfg = precisaRepo ? config(RAIZ) : null;
const VCFG = { tetoTokensFatia: 30000, staleMeses: 6, staleMesesDependencias: 3, clone: null, squad: null, ...(cfg?.vault || {}) };
const ID_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const hoje = () => new Date().toISOString().slice(0, 10);
const tokens = (bytes) => Math.ceil(bytes / 4);
const hash = (t) => createHash('sha256').update(t).digest('hex');
const pasta = (id) => join(RAIZ, HW, 'vault', id);
const relHw = (p) => barra(relative(RAIZ, p));
const NOME_PLUGIN = () => lerJson(join(RAIZ, HW, 'versao.json'), {})?.plugin || PLUGIN_PADRAO;

function exigirId(id) {
  if (!id || !ID_RE.test(id)) sair(2, 'informe o id da extração em kebab-case, como "renegociacao-web".');
  return id;
}
function nomeDoRepo() {
  const url = (git(['remote', 'get-url', 'origin'], { cwd: RAIZ, permitirFalha: true }) || '').trim();
  const n = url ? basename(url).replace(/\.git$/, '') : basename(raizGit(RAIZ) || RAIZ);
  return n.replace(/[^A-Za-z0-9._-]/g, '-');
}
const lerEstado = (id) => lerJson(join(pasta(id), 'estado.json'), null);
const gravarEstado = (id, e) => gravarJson(join(pasta(id), 'estado.json'), e);
function imprimirProblemas(arquivo, ps) {
  for (const p of ps) console.log(`  ${p.nivel === 'erro' ? 'ERRO ' : 'aviso'} ${arquivo}${p.linha ? `:${p.linha}` : ''}  ${p.regra}  ${p.msg}`);
}

// ------------------------------------------------------------------ inventário

const EXCLUIR = [
  ['estado do fluxo', /^\.bchive\//],
  ['personalização', /^\.(github|vscode|idea)\//],
  ['pipeline', /(?:^|\/)(?:Jenkinsfile[^/]*|azure-pipelines[^/]*\.ya?ml|\.gitlab-ci\.ya?ml|bitbucket-pipelines\.ya?ml|Dockerfile[^/]*|docker-compose[^/]*\.ya?ml)$|^\.(?:circleci|buildkite)\//],
  ['infraestrutura', /(?:^|\/)(?:k8s|kubernetes|helm|charts|terraform|infra|deploy|deployment|manifests)\//],
  ['gerado', /(?:^|\/)(?:dist|build|target|out|coverage|node_modules|\.angular|generated|vendor)\//],
  ['lock', /(?:^|\/)(?:package-lock\.json|yarn\.lock|pnpm-lock\.yaml|[^/]+\.lock)$/],
  ['configuração', /(?:^|\/)(?:\.env[^/]*|[^/]+\.config\.(?:js|ts|mjs|cjs|json)|tsconfig[^/]*\.json|angular\.json|nx\.json|project\.json|\.eslintrc[^/]*|\.prettierrc[^/]*|\.editorconfig|\.npmrc|application[^/]*\.(?:properties|ya?ml)|bootstrap[^/]*\.ya?ml|environment[^/]*\.ts|settings\.gradle(?:\.kts)?|gradle\.properties|[^/]+\.(?:properties|ini|toml|conf|cfg))$/],
];
const DEPENDENCIAS = /(?:^|\/)(?:package\.json|pom\.xml|build\.gradle(?:\.kts)?|requirements[^/]*\.txt|go\.mod|[^/]+\.csproj)$/;
const CODIGO = /\.(?:ts|tsx|js|jsx|mjs|cjs|java|kt|cs|py|go|rb|php|scala|html|vue|svelte|sql|md)$/i;
const TESTE = /(?:[._](?:spec|test)\.[a-z]+$)|(?:^|\/)(?:test|tests|__tests__|spec|src\/test)\//i;

function classificar(rel) {
  for (const [motivo, re] of EXCLUIR) if (re.test(rel)) return { fora: motivo };
  if (DEPENDENCIAS.test(rel)) return { tipo: 'dependencias' };
  if (!CODIGO.test(rel)) return { fora: 'tipo de arquivo' };
  return { tipo: TESTE.test(rel) ? 'teste' : rel.toLowerCase().endsWith('.md') ? 'documento' : 'codigo' };
}

// Agrupa por pasta, descendo um nível onde o grupo passa do teto. Os arquivos soltos de uma pasta grande viram
// blocos que cabem no teto; um arquivo sozinho acima do teto vira módulo com partes (o plano cita faixas #Lx-Ly).
function agrupar(arquivos, teto) {
  const modulos = [];
  const soma = (l) => l.reduce((s, a) => s + a.tokens, 0);
  const blocos = (prefixo, lista) => {
    const nome = `${prefixo || '.'}/*`;
    let bloco = []; let t = 0; let k = 0;
    const fechar = () => { if (bloco.length) { k++; modulos.push({ nome: k > 1 ? `${nome} (${k})` : nome, arquivos: bloco.map((a) => a.path), tokens: t }); } bloco = []; t = 0; };
    for (const a of [...lista].sort((x, y) => x.path.localeCompare(y.path))) {
      if (a.tokens > teto) { modulos.push({ nome: a.path, arquivos: [a.path], tokens: a.tokens, partes: Math.ceil(a.tokens / teto) }); continue; }
      if (t + a.tokens > teto) fechar();
      bloco.push(a); t += a.tokens;
    }
    fechar();
  };
  const dividir = (prefixo, lista) => {
    const total = soma(lista);
    if (total <= teto) { modulos.push({ nome: prefixo || '.', arquivos: lista.map((a) => a.path), tokens: total }); return; }
    const resto = (a) => (prefixo ? a.path.slice(prefixo.length + 1) : a.path);
    const diretos = lista.filter((a) => !resto(a).includes('/'));
    const sub = new Map();
    for (const a of lista.filter((x) => resto(x).includes('/'))) {
      const seg = resto(a).split('/')[0];
      if (!sub.has(seg)) sub.set(seg, []);
      sub.get(seg).push(a);
    }
    if (diretos.length) blocos(prefixo, diretos);
    for (const [seg, g] of sub) dividir(prefixo ? `${prefixo}/${seg}` : seg, g);
  };
  if (arquivos.length) dividir('', arquivos);
  return modulos;
}

function inventario(id) {
  const teto = Number(op.teto || VCFG.tetoTokensFatia);
  const spec = [...(op.escopo || []), ...excluirPathspec(cfg, RAIZ)];
  const lista = (git(['ls-files', '-z', '--', ...(op.escopo?.length ? spec : ['.', ...spec])], { cwd: RAIZ }) || '').split('\0').filter(Boolean);
  const dentro = []; const fora = {};
  for (const rel of lista) {
    const c = classificar(rel);
    if (c.fora) { fora[c.fora] = (fora[c.fora] || 0) + 1; continue; }
    let bytes = 0;
    try { bytes = statSync(join(RAIZ, rel)).size; } catch { fora['ilegível'] = (fora['ilegível'] || 0) + 1; continue; }
    dentro.push({ path: rel, tipo: c.tipo, tokens: tokens(bytes) });
  }
  const modulos = agrupar(dentro.filter((a) => a.tipo !== 'dependencias'), teto);
  const dep = dentro.filter((a) => a.tipo === 'dependencias');
  if (dep.length) modulos.push({ nome: 'dependencias', arquivos: dep.map((a) => a.path), tokens: dep.reduce((s, a) => s + a.tokens, 0) });
  const inv = { id, repo: nomeDoRepo(), commit: headCurto(RAIZ), criadoEm: new Date().toISOString(), teto, totalTokens: dentro.reduce((s, a) => s + a.tokens, 0), arquivos: dentro, modulos, fora };
  mkdirSync(pasta(id), { recursive: true });
  gravarJson(join(pasta(id), 'inventario.json'), inv);
  console.log(`Inventário ${id}: ${dentro.length} arquivo(s), ~${inv.totalTokens.toLocaleString('pt-BR')} tokens, teto por fatia ${teto.toLocaleString('pt-BR')}.`);
  console.log(`  repositório ${inv.repo} @ ${inv.commit}`);
  for (const m of modulos) console.log(`  ${m.nome.padEnd(48)} ${String(m.arquivos.length).padStart(4)} arq  ~${m.tokens.toLocaleString('pt-BR')} tokens${m.partes ? `  (${m.partes} partes)` : ''}`);
  const f = Object.entries(fora).map(([k, v]) => `${k} ${v}`).join(', ');
  if (f) console.log(`  fora: ${f}`);
  console.log(`\nPróximo: o agente escreve ${relHw(join(pasta(id), 'plano.json'))} e roda "okf.mjs plano ${id}".`);
}

// ------------------------------------------------------------------ plano

function faixaDe(item) {
  const m = /^(.+?)(?:#L(\d+)-L(\d+))?$/.exec(item);
  return { path: m[1], de: m[2] ? Number(m[2]) : null, ate: m[3] ? Number(m[3]) : null };
}
function linhasDoArquivo(rel) { return readFileSync(join(RAIZ, rel), 'utf8').replace(/\r\n/g, '\n').split('\n'); }
function tokensDaFaixa(rel, de, ate) {
  if (!de) return tokens(statSync(join(RAIZ, rel)).size);
  return tokens(Buffer.byteLength(linhasDoArquivo(rel).slice(de - 1, ate).join('\n')));
}

function validarPlano(id, { silencioso = false } = {}) {
  const inv = lerJson(join(pasta(id), 'inventario.json'));
  if (!inv) sair(2, `sem inventário: rode "okf.mjs inventario ${id}" antes.`);
  const p = join(pasta(id), 'plano.json');
  if (!existsSync(p)) sair(2, `sem plano: o agente escreve ${relHw(p)}.`);
  let plano;
  try { plano = JSON.parse(readFileSync(p, 'utf8')); } catch (e) { sair(1, `plano.json inválido: ${e.message}`); }
  const erros = []; const avisos = [];
  const conhecidos = new Map(inv.arquivos.map((a) => [a.path, a]));
  if (!plano.squad || !SEGMENTO.test(plano.squad)) erros.push('squad: nome da pasta da squad em kebab-case, sem acento');
  if (!Array.isArray(plano.fatias) || !plano.fatias.length) erros.push('fatias: lista com ao menos uma fatia');
  const nns = new Set(); const notas = new Map(); const cobertos = new Set();
  for (const f of plano.fatias || []) {
    const rot = `fatia ${f.nn ?? '?'}`;
    if (!/^\d{2}$/.test(f.nn || '') || nns.has(f.nn)) erros.push(`${rot}: nn com dois dígitos, sem repetir`);
    nns.add(f.nn);
    if (!f.titulo) erros.push(`${rot}: sem titulo`);
    let soma = 0;
    for (const item of f.arquivos || []) {
      const { path, de, ate } = faixaDe(item);
      if (!conhecidos.has(path)) { erros.push(`${rot}: ${path} não está no inventário (fora do escopo ou excluído)`); continue; }
      if (de && (!(ate >= de) || ate > linhasDoArquivo(path).length)) { erros.push(`${rot}: faixa inválida em ${item}`); continue; }
      soma += tokensDaFaixa(path, de, ate);
      cobertos.add(path);
    }
    if (!(f.arquivos || []).length) erros.push(`${rot}: sem arquivos`);
    if (soma > inv.teto) erros.push(`${rot}: ~${soma} tokens, acima do teto de ${inv.teto}; divida a fatia ou use faixas (arquivo#L1-L400)`);
    f.tokens = soma;
    if (!(f.notas || []).length) erros.push(`${rot}: sem notas previstas`);
    for (const n of f.notas || []) {
      const segs = String(n.caminho || '').split('/');
      if (!n.caminho || segs.slice(0, -1).some((s) => !SEGMENTO.test(s)) || !ARQUIVO_NOTA.test(segs.at(-1)) || /(?:^|\/)(?:index|log)\.md$/.test(n.caminho)) erros.push(`${rot}: caminho "${n.caminho}" fora do padrão (kebab-case, .md, relativo à pasta da squad; index.md e log.md são reservados)`);
      if (!TIPOS.includes(n.tipo)) erros.push(`${rot}: tipo "${n.tipo}" fora da lista: ${TIPOS.join(', ')}`);
      if (!n.titulo) erros.push(`${rot}: nota ${n.caminho} sem titulo`);
      if (notas.has(n.caminho)) erros.push(`${rot}: a nota ${n.caminho} já está na fatia ${notas.get(n.caminho)}; uma nota por fatia (a consolidação junta)`);
      notas.set(n.caminho, f.nn);
    }
  }
  const semFatia = inv.arquivos.filter((a) => !cobertos.has(a.path));
  if (semFatia.length) avisos.push(`${semFatia.length} arquivo(s) do inventário fora das fatias (ok se for de propósito): ${semFatia.slice(0, 5).map((a) => a.path).join(', ')}${semFatia.length > 5 ? '…' : ''}`);
  const clone = op.vault || VCFG.clone;
  if (clone && ehCloneDoVault(resolve(RAIZ, clone))) {
    const o = orcamento(resolve(RAIZ, clone));
    const previsto = o.arquivos + notas.size + 8;
    if (previsto > o.limiteArquivos) erros.push(`orçamento: o Vault tem ${o.arquivos} arquivo(s) e o plano soma ${notas.size} nota(s) mais índices; passa de ${o.limiteArquivos}`);
    else if (previsto > o.limiteArquivos * 0.8) avisos.push(`orçamento: depois da publicação o Vault fica com ~${previsto} de ${o.limiteArquivos} arquivos`);
  }
  if (!silencioso) {
    console.log(`Plano ${id}: squad ${plano.squad}, ${(plano.fatias || []).length} fatia(s), ${notas.size} nota(s).`);
    for (const f of plano.fatias || []) console.log(`  ${f.nn}  ~${String(f.tokens ?? 0).padStart(6)} tokens  ${(f.notas || []).length} nota(s)  ${f.titulo || ''}`);
    for (const a of avisos) console.log(`  aviso ${a}`);
    for (const e of erros) console.log(`  ERRO  ${e}`);
  }
  return { plano, erros, avisos, hash: hash(readFileSync(p, 'utf8')), inv };
}

function plano(id) {
  const { plano: pl, erros, hash: h } = validarPlano(id);
  if (erros.length) sair(1, '\nCorrija o plano e rode de novo.');
  const est = lerEstado(id) || {};
  const fatias = Object.fromEntries(pl.fatias.map((f) => [f.nn, est.fatias?.[f.nn] && est.plano === h ? est.fatias[f.nn] : 'pendente']));
  gravarEstado(id, { ...est, plano: h, aprovado: est.plano === h ? est.aprovado || null : null, fatias });
  console.log(`\nPlano conferido. Portão humano: o dev revisa e roda no terminal dele:\n  node ${HW}/bin/okf.mjs aprovar-plano ${id} --por <login>`);
}

function aprovarPlano(id) {
  if (!op.por || op.por === true || !LOGIN.test(String(op.por).replace(/^human:/, ''))) sair(2, 'informe quem aprova: --por <login>');
  const { erros, hash: h } = validarPlano(id, { silencioso: true });
  if (erros.length) sair(1, 'o plano tem erros: rode "okf.mjs plano" e corrija antes de aprovar.');
  const est = lerEstado(id);
  if (!est || est.plano !== h) sair(1, `o plano mudou depois da conferência: rode "okf.mjs plano ${id}" de novo.`);
  gravarEstado(id, { ...est, aprovado: { por: String(op.por).replace(/^human:/, ''), em: new Date().toISOString(), hash: h } });
  console.log(`Plano ${id} aprovado por ${op.por}. O agente segue com "okf.mjs pacote ${id} <NN>".`);
}

function planoAprovado(id) {
  const { plano: pl, erros, hash: h, inv } = validarPlano(id, { silencioso: true });
  const est = lerEstado(id);
  if (erros.length) sair(1, 'o plano tem erros: rode "okf.mjs plano".');
  if (!est?.aprovado || est.aprovado.hash !== h) sair(1, `plano sem aprovação vigente: o dev roda "node ${HW}/bin/okf.mjs aprovar-plano ${id} --por <login>" no terminal dele.`);
  return { pl, est, inv };
}

// ------------------------------------------------------------------ pacote da fatia

const REGRAS_NOTA = [
  'Write in the language of the source (Portuguese for this bank); frontmatter keys and `type` values in US English.',
  'NO code in the note: no fenced block (only ```mermaid diagrams), no indented code, no inline code with backticks, no <pre>/<code>. Describe behaviour, rules, layers and patterns in prose; write identifiers as plain words.',
  'Never copy credentials, hostnames, IP addresses, cluster or bucket names, endpoints, customer data, CPF/CNPJ, e-mails or phone numbers, even from tests or fixtures. Describe systems by their logical role.',
  'Frontmatter you write: type (one of the list), title, description (one sentence), tags, sources (each: id in kebab-case, resource "path#Lx-Ly" from this package). The script fills status, generated, stale_after and the repository; never write verified.',
  'Quote every text value in the frontmatter with double quotes.',
  'Every claim (paragraph or list item) cites its source with a footnote [^id] whose id is in sources, and the note ends with the footnote definitions: [^id]: path#Lx-Ly.',
  'Every note has a "## Perguntas em aberto" section: what the code shows but cannot explain (rule or bug?), or "Nenhuma.". When the code contradicts a comment, a test or a name, say so there.',
  'Code shows behaviour, not intent: write "o código faz X", never invent the business reason.',
  'Coding Standard: the pattern, where it applies and what is forbidden, in prose. Dependency Baseline: only versions the team must keep and why, never a copy of the manifest.',
  'Links between notes are relative Markdown links ([Título](outra-nota.md)); never wikilinks, never a link that starts with "/".',
  'Use roles, never people\'s names.',
];

function pacote(id, nn) {
  const { pl, est, inv } = planoAprovado(id);
  const f = pl.fatias.find((x) => x.nn === nn);
  if (!f) sair(2, `fatia ${nn} não existe no plano.`);
  const base = relHw(pasta(id));
  const out = [];
  out.push(`# Extraction package ${id} · slice ${nn}: ${f.titulo}`, '');
  out.push(`Squad: ${pl.squad} · Repository: ${inv.repo} @ ${inv.commit}`, '');
  out.push('## Write exactly these notes', '');
  for (const n of f.notas) out.push(`- ${base}/rascunhos/${n.caminho} · type: ${n.tipo} · title: ${n.titulo}${n.foco ? ` · focus: ${n.foco}` : ''}`);
  out.push('', `Then write ${base}/resumos/${nn}.md: at most 300 words, what each note covers and the open questions. No code.`, '');
  out.push('## Rules', '', ...REGRAS_NOTA.map((r) => `- ${r}`), '');
  out.push('Only the files below are your source. Do not read other files. Each line starts with its number: cite as path#Lx-Ly.', '');
  for (const item of f.arquivos) {
    const { path, de, ate } = faixaDe(item);
    const linhas = linhasDoArquivo(path);
    const a = de || 1; const b = ate || linhas.length;
    out.push(`## File: ${path} (L${a}-L${b})`, '');
    for (let i = a; i <= b; i++) out.push(`L${i}: ${linhas[i - 1]}`);
    out.push('');
  }
  const texto = out.join('\n');
  const arq = join(pasta(id), 'pacotes', `${nn}.md`);
  mkdirSync(dirname(arq), { recursive: true });
  writeFileSync(arq, texto);
  gravarEstado(id, { ...est, fatias: { ...est.fatias, [nn]: est.fatias[nn] === 'feita' ? 'feita' : 'em-andamento' }, pacotes: { ...(est.pacotes || {}), [nn]: hash(texto) } });
  console.log(`Pacote: ${relHw(arq)} (~${Math.ceil(texto.length / 4).toLocaleString('pt-BR')} tokens).`);
  console.log(`Prompt literal para o subagente extrator:\nExtraction package: ${relHw(arq)}. Read that file and follow it.`);
}

// ------------------------------------------------------------------ concluir, checar, revisão

function normalizarEConferir(id, inv, caminhos) {
  let erros = 0;
  for (const c of caminhos) {
    const arq = join(pasta(id), 'rascunhos', c);
    if (!existsSync(arq)) { console.log(`  ERRO  rascunhos/${c}: não foi escrito`); erros++; continue; }
    const n = normalizarRascunho(readFileSync(arq, 'utf8'), { repo: inv.repo, commit: inv.commit, plugin: NOME_PLUGIN(), meses: VCFG.staleMeses, mesesDependencias: VCFG.staleMesesDependencias });
    if (n.texto !== readFileSync(arq, 'utf8')) writeFileSync(arq, n.texto);
    const doNormalizador = n.erros.map((m) => ({ nivel: 'erro', regra: 'okf/frontmatter', msg: m }));
    const ps = [...doNormalizador, ...checarNota(n.texto, c, { fase: 'rascunho' }).filter((p) => !doNormalizador.some((q) => q.msg === p.msg))];
    imprimirProblemas(`rascunhos/${c}`, ps);
    erros += ps.filter((p) => p.nivel === 'erro').length;
  }
  return erros;
}

function concluir(id, nn) {
  const { pl, est, inv } = planoAprovado(id);
  const f = pl.fatias.find((x) => x.nn === nn);
  if (!f) sair(2, `fatia ${nn} não existe no plano.`);
  console.log(`Fatia ${nn}: ${f.titulo}`);
  let erros = normalizarEConferir(id, inv, f.notas.map((n) => n.caminho));
  const r = join(pasta(id), 'resumos', `${nn}.md`);
  if (!existsSync(r)) { console.log(`  ERRO  resumos/${nn}.md: não foi escrito`); erros++; } else {
    const t = readFileSync(r, 'utf8');
    if (t.split(/\s+/).filter(Boolean).length > 400) { console.log(`  ERRO  resumos/${nn}.md: mais de 400 palavras`); erros++; }
    if (/```|`/.test(t)) { console.log(`  ERRO  resumos/${nn}.md: tem código`); erros++; }
  }
  if (erros) sair(1, `\n${erros} erro(s): o extrator corrige os rascunhos da fatia ${nn} e roda "okf.mjs concluir ${id} ${nn}" de novo.`);
  gravarEstado(id, { ...est, fatias: { ...est.fatias, [nn]: 'feita' } });
  const falta = Object.entries({ ...est.fatias, [nn]: 'feita' }).filter(([, s]) => s !== 'feita').map(([k]) => k);
  console.log(`Fatia ${nn} feita.${falta.length ? ` Faltam: ${falta.join(', ')}.` : ' Todas feitas: consolidar e rodar "okf.mjs revisao".'}`);
}

function rascunhos(id) {
  const base = join(pasta(id), 'rascunhos');
  const out = [];
  const andar = (d) => { if (!existsSync(d)) return; for (const n of readdirSync(d)) { const p = join(d, n); if (statSync(p).isDirectory()) andar(p); else out.push(barra(relative(base, p))); } };
  andar(base);
  return out.sort();
}

function checar(id) {
  const inv = lerJson(join(pasta(id), 'inventario.json'));
  if (!inv) sair(2, `extração ${id} sem inventário.`);
  const lista = rascunhos(id);
  for (const c of lista.filter((x) => !x.endsWith('.md'))) console.log(`  ERRO  rascunhos/${c}: o extrator só escreve notas .md (imagem, PDF e dados entram pelo curador, com conferência humana)`);
  const erros = normalizarEConferir(id, inv, lista.filter((x) => x.endsWith('.md'))) + lista.filter((x) => !x.endsWith('.md')).length;
  console.log(erros ? `\n${erros} erro(s) em ${lista.length} rascunho(s).` : `${lista.length} rascunho(s) sem erro.`);
  if (erros) process.exit(1);
}

const slug = (c) => c.replace(/\.md$/, '').replace(/\//g, '__');
const VEREDITO = /^# (\S+) - (APROVADO|REPROVADO)\b/;

function revisao(id) {
  const { est, inv } = planoAprovado(id);
  const pend = Object.entries(est.fatias).filter(([, s]) => s !== 'feita').map(([k]) => k);
  if (pend.length) sair(1, `fatias ainda não feitas: ${pend.join(', ')}.`);
  const head = headCurto(RAIZ);
  if (head !== inv.commit) console.log(`AVISO o HEAD (${head}) não é o commit do inventário (${inv.commit}): as linhas citadas podem ter mudado.`);
  const base = relHw(pasta(id));
  const prompts = [];
  for (const c of rascunhos(id).filter((x) => x.endsWith('.md'))) {
    const v = join(pasta(id), 'revisao', `${slug(c)}.md`);
    const nota = readFileSync(join(pasta(id), 'rascunhos', c), 'utf8');
    if (existsSync(v)) {
      const reg = lerJson(join(pasta(id), 'revisao', 'notas.json'), {});
      if (reg[c] === hash(nota)) continue; // revisada e sem mudança
    }
    const out = [`# Vault review package · ${c}`, '', `Write your verdict to ${base}/revisao/${slug(c)}.md. First line exactly "# ${slug(c)} - APROVADO" or "# ${slug(c)} - REPROVADO", then the findings.`, '',
      '## What to check', '',
      '- Fidelity: each claim is what the cited lines show. A claim the lines do not support, or a business reason the code does not state, is a finding.',
      '- Exposure: credential, host, IP, cluster, bucket, endpoint, customer or personal data, or any code in the note is a finding.',
      '- Open questions: what the code cannot explain is listed, not guessed.',
      '- Language: Portuguese prose, roles instead of people.', '',
      'REPROVADO when any claim is unsupported or anything is exposed. Never edit the note.', '', '## Note', '', nota, '', '## Cited lines', ''];
    const n = lerNota(nota);
    for (const s of Array.isArray(n.dados.sources) ? n.dados.sources : []) {
      const semRepo = String(s.resource || '').startsWith(`${inv.repo}/`) ? String(s.resource).slice(inv.repo.length + 1) : String(s.resource || '');
      const m = /^(.+?)#L(\d+)-L(\d+)$/.exec(semRepo);
      if (!m || !existsSync(join(RAIZ, m[1]))) { out.push(`### [^${s.id}] ${s.resource}: not found in the working tree`, ''); continue; }
      const ls = linhasDoArquivo(m[1]);
      out.push(`### [^${s.id}] ${m[1]} (L${m[2]}-L${m[3]})`, '');
      for (let i = Number(m[2]); i <= Math.min(Number(m[3]), ls.length); i++) out.push(`L${i}: ${ls[i - 1]}`);
      out.push('');
    }
    const arq = join(pasta(id), 'revisao', 'pacotes', `${slug(c)}.md`);
    mkdirSync(dirname(arq), { recursive: true });
    writeFileSync(arq, out.join('\n'));
    const reg = lerJson(join(pasta(id), 'revisao', 'notas.json'), {});
    gravarJson(join(pasta(id), 'revisao', 'notas.json'), { ...reg, [c]: hash(nota) });
    prompts.push(`Vault review package: ${relHw(arq)}. Read that file and follow it.`);
  }
  console.log(prompts.length ? `${prompts.length} pacote(s) de revisão. Prompt literal de cada chamada ao subagente revisor:\n${prompts.join('\n')}` : 'Todas as notas já têm veredito para a versão atual.');
}

// ------------------------------------------------------------------ publicar

function publicar(id) {
  const clone = op.vault && op.vault !== true ? resolve(RAIZ, op.vault) : VCFG.clone ? resolve(RAIZ, VCFG.clone) : null;
  if (!clone || !ehCloneDoVault(clone)) sair(2, 'informe o clone do Vault: --vault <pasta> (plugin.json com a extensão do Vault e vault/), ou vault.clone no bchive.json.');
  const { pl, est, inv } = planoAprovado(id);
  const pend = Object.entries(est.fatias).filter(([, s]) => s !== 'feita').map(([k]) => k);
  if (pend.length) sair(1, `fatias ainda não feitas: ${pend.join(', ')}.`);
  const squad = op.squad && op.squad !== true ? op.squad : pl.squad;
  if (!SEGMENTO.test(squad)) sair(2, 'squad em kebab-case.');
  const lista = rascunhos(id).filter((x) => x.endsWith('.md'));
  if (!lista.length) sair(1, 'nenhum rascunho para publicar.');
  // Revisão: toda nota com veredito APROVADO para a versão atual.
  const reg = lerJson(join(pasta(id), 'revisao', 'notas.json'), {});
  const semRevisao = [];
  for (const c of lista) {
    const v = join(pasta(id), 'revisao', `${slug(c)}.md`);
    const t = existsSync(v) ? readFileSync(v, 'utf8') : '';
    const m = VEREDITO.exec(t);
    const nota = readFileSync(join(pasta(id), 'rascunhos', c), 'utf8');
    if (!m || m[1] !== slug(c) || m[2] !== 'APROVADO' || reg[c] !== hash(nota)) semRevisao.push(`${c}${m?.[2] === 'REPROVADO' ? ' (REPROVADO)' : ''}`);
  }
  if (semRevisao.length) sair(1, `notas sem revisão aprovada para a versão atual: ${semRevisao.join(', ')}. Rode "okf.mjs revisao ${id}" e o revisor; nota reprovada volta ao extrator.`);
  if (normalizarEConferir(id, inv, lista)) sair(1, 'rascunhos com erro: corrija antes de publicar.');

  // Aplica numa cópia, valida as duas camadas e só então copia para o clone.
  const tmp = copiaTemporaria(clone);
  try {
    const escritos = [];
    const dia = hoje();
    for (const c of lista) {
      const destRel = `vault/squads/${squad}/${c}`;
      const destino = join(tmp.pasta, destRel);
      const existia = existsSync(destino);
      const texto = readFileSync(join(pasta(id), 'rascunhos', c), 'utf8');
      if (existia && readFileSync(destino, 'utf8') === texto) continue; // igual ao que já está no Vault
      mkdirSync(dirname(destino), { recursive: true });
      writeFileSync(destino, texto);
      escritos.push(destRel);
      const n = lerNota(texto);
      const desc = { squads: 'Conhecimento de cada squad da tribo', [`squads/${squad}`]: `Conhecimento da squad ${squad}`, ...Object.fromEntries(Object.entries(pl.diretorios || {}).map(([k, v]) => [`squads/${squad}/${k}`, v])) };
      indexarNota(tmp.pasta, destRel, n.dados.title, n.dados.description, desc);
      const pLog = join(tmp.pasta, 'vault', 'log.md');
      writeFileSync(pLog, registrarNoLog(existsSync(pLog) ? readFileSync(pLog, 'utf8') : '# Log\n', dia, `${existia ? 'Atualizada' : 'Adicionada'} a nota [${String(n.dados.title).replace(/[[\]]/g, '')}](${destRel.replace(/^vault\//, '')}).`));
    }
    // Camada do Hive em toda nota do Vault (as de fora do extrator só nas regras de conteúdo) + catálogo + orçamento.
    let erros = 0;
    for (const rel of notasDoVault(tmp.pasta)) {
      const ps = checarNota(readFileSync(join(tmp.pasta, rel), 'utf8'), rel, { fase: 'vault' });
      const meus = escritos.includes(rel);
      const relevantes = meus ? ps : ps.filter((p) => p.nivel === 'erro');
      if (relevantes.length) { imprimirProblemas(rel, relevantes); erros += relevantes.filter((p) => p.nivel === 'erro' && meus).length; }
    }
    const cat = checarCatalogo(tmp.pasta);
    for (const a of cat) console.log(`  ${a.nivel === 'erro' ? 'ERRO ' : 'aviso'} ${a.arquivo}  ${a.regra}  ${a.msg}`);
    erros += cat.filter((a) => a.nivel === 'erro').length;
    const o = orcamento(tmp.pasta);
    if (o.arquivos > o.limiteArquivos * 0.8) console.log(`  aviso orçamento: ${o.arquivos} de ${o.limiteArquivos} arquivos em vault/`);
    if (erros) sair(1, `\n${erros} erro(s): nada foi escrito no clone.`);
    // Copia para o clone só o que mudou: notas, índices e log.
    const mudados = notasEIndices(tmp.pasta, clone);
    if (!escritos.length) { console.log('Nada novo: as notas já estão no Vault como estão nos rascunhos.'); return; }
    for (const rel of mudados) { mkdirSync(dirname(join(clone, rel)), { recursive: true }); cpSync(join(tmp.pasta, rel), join(clone, rel)); }
    gravarEstado(id, { ...est, publicado: { em: new Date().toISOString(), clone: barra(clone), squad, notas: escritos } });
    console.log(`Publicado no clone: ${escritos.length} nota(s), ${mudados.length - escritos.length} índice(s)/log. Checagem do catálogo: 0 erros.`);
    console.log(`\nNo Git Bash, revise e abra a PR (título em inglês, feat: gera versão minor):\n  cd "${barra(clone)}"\n  git switch -c feat/${id}\n  git add vault\n  git commit -m "feat: add ${squad} notes from ${inv.repo.replace(/[^\w ]/g, ' ').replace(/\s+/g, ' ').trim()}"\n  git push -u origin feat/${id}`);
    console.log('As notas sobem como draft, sem verified. Quem confirmar contra a fonte roda "okf.mjs confirmar <nota> --por <login>".');
  } finally { tmp.apagar(); }
}

function notasEIndices(tmp, clone) {
  const out = [];
  const andar = (d) => { for (const n of readdirSync(join(tmp, d))) { const rel = posix.join(d, n); const p = join(tmp, rel); if (statSync(p).isDirectory()) andar(rel); else { const q = join(clone, rel); if (!existsSync(q) || !readFileSync(q).equals(readFileSync(p))) out.push(rel); } } };
  andar('vault');
  return out;
}

// ------------------------------------------------------------------ checar-vault e confirmar

function checarVault(dir) {
  const clone = resolve(RAIZ, dir || '.');
  if (!ehCloneDoVault(clone)) sair(2, `${dir || '.'} não é o clone de um Vault (plugin.json com a extensão do Vault e vault/).`);
  let erros = 0;
  for (const rel of notasDoVault(clone)) {
    const ps = checarNota(readFileSync(join(clone, rel), 'utf8'), rel, { fase: 'vault' });
    imprimirProblemas(rel, ps);
    erros += ps.filter((p) => p.nivel === 'erro').length;
  }
  const cat = checarCatalogo(clone);
  for (const a of cat) console.log(`  ${a.nivel === 'erro' ? 'ERRO ' : 'aviso'} ${a.arquivo}  ${a.regra}  ${a.msg}`);
  erros += cat.filter((a) => a.nivel === 'erro').length;
  const o = orcamento(clone);
  console.log(`${notasDoVault(clone).length} nota(s); ${o.arquivos} de ${o.limiteArquivos} arquivos; ${(o.bytes / 1048576).toFixed(1)} de ${o.limiteBytes / 1048576} MiB. ${erros ? `${erros} erro(s).` : 'Sem erro.'}`);
  if (erros) process.exit(1);
}

function confirmar(arquivo) {
  if (!arquivo) sair(2, 'informe a nota: okf.mjs confirmar <caminho da nota no clone> --por <login>');
  const login = String(op.por || '').replace(/^human:/, '');
  if (!login || !LOGIN.test(login)) sair(2, 'informe quem confirmou contra a fonte: --por <login>');
  const abs = resolve(RAIZ, arquivo);
  let clone = dirname(abs);
  while (!ehCloneDoVault(clone) && dirname(clone) !== clone) clone = dirname(clone);
  if (!ehCloneDoVault(clone) || !existsSync(abs)) sair(2, 'a nota precisa estar em vault/ de um clone do Vault.');
  const rel = barra(relative(clone, abs));
  const n = lerNota(readFileSync(abs, 'utf8'));
  if (!n.present || n.error) sair(1, `frontmatter inválido: ${n.error || 'ausente'}`);
  const d = { ...n.dados };
  const lista = Array.isArray(d.verified) ? d.verified : d.verified && typeof d.verified === 'object' ? [d.verified] : [];
  const agora = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  d.verified = [...lista.filter((v) => v?.by !== `human:${login}`), { by: `human:${login}`, at: agora }];
  if (d.status === 'draft' || d.status === undefined) d.status = 'stable';
  const texto = `${renderizarFrontmatter(d)}${n.corpo.startsWith('\n') ? '' : '\n'}${n.corpo}`;
  const ps = checarNota(texto, rel, { fase: 'vault' }).filter((p) => p.nivel === 'erro');
  if (ps.length) { imprimirProblemas(rel, ps); sair(1, 'a nota tem erro: corrija antes de confirmar.'); }
  writeFileSync(abs, texto);
  const pLog = join(clone, 'vault', 'log.md');
  writeFileSync(pLog, registrarNoLog(existsSync(pLog) ? readFileSync(pLog, 'utf8') : '# Log\n', hoje(), `Confirmada a nota [${String(d.title || basename(rel)).replace(/[[\]]/g, '')}](${rel.replace(/^vault\//, '')}) contra a fonte.`));
  console.log(`${rel}: verified por human:${login}, status ${d.status}. Commit com "fix: confirm ..." (gera versão patch).`);
}

function estado(id) {
  const raiz = join(RAIZ, HW, 'vault');
  const ids = id ? [id] : existsSync(raiz) ? readdirSync(raiz).filter((x) => existsSync(join(raiz, x, 'estado.json')) || existsSync(join(raiz, x, 'inventario.json'))) : [];
  if (!ids.length) { console.log('Nenhuma extração. Comece com "okf.mjs inventario <extracao> --escopo <pasta>".'); return; }
  for (const x of ids) {
    const e = lerEstado(x) || {};
    const fs = Object.entries(e.fatias || {});
    console.log(`${x}: plano ${e.plano ? (e.aprovado?.hash === e.plano ? `aprovado por ${e.aprovado.por}` : 'conferido, sem aprovação') : 'não escrito'}; fatias ${fs.filter(([, s]) => s === 'feita').length}/${fs.length}${e.publicado ? `; publicado em ${e.publicado.em.slice(0, 10)}` : ''}`);
    for (const [k, s] of fs) console.log(`  ${k} ${s}`);
  }
}

switch (cmd) {
  case 'inventario': inventario(exigirId(pos[0])); break;
  case 'plano': plano(exigirId(pos[0])); break;
  case 'aprovar-plano': aprovarPlano(exigirId(pos[0])); break;
  case 'pacote': pacote(exigirId(pos[0]), String(pos[1] || '').padStart(2, '0')); break;
  case 'concluir': concluir(exigirId(pos[0]), String(pos[1] || '').padStart(2, '0')); break;
  case 'revisao': revisao(exigirId(pos[0])); break;
  case 'checar': checar(exigirId(pos[0])); break;
  case 'checar-vault': checarVault(pos[0]); break;
  case 'publicar': publicar(exigirId(pos[0])); break;
  case 'confirmar': confirmar(pos[0]); break;
  case 'estado': estado(pos[0] ? exigirId(pos[0]) : null); break;
  default:
    console.log('uso: okf.mjs inventario|plano|aprovar-plano|pacote|concluir|revisao|checar|checar-vault|publicar|confirmar|estado (ver o cabeçalho do script)');
    process.exit(cmd ? 2 : 0);
}
