#!/usr/bin/env node
// b.IA Credit Hive - teste de fumaça do plugin. Sem dependência, Node 20+, sem rede.
//
//   node testes/smoke.mjs [--manter]
//
// Cria um repositório Git temporário, roda o init do plugin nele (como o /<plugin>:init faz), percorre o
// fluxo inteiro por script (plano, revisão da spec, implementação, revisão de código, archive, OK do QA,
// conhecimento), confere as guardas do hook com eventos no formato do harness Copilot e a coleta de uso.
// Nada fora da pasta temporária é tocado: uso, telemetria e casa do usuário vão para dentro dela.

import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync, existsSync, rmSync, statSync, symlinkSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';

const PLUGIN = join(dirname(fileURLToPath(import.meta.url)), '..');
const MANIF = JSON.parse(readFileSync(join(PLUGIN, 'plugin.json'), 'utf8'));
const NOME = MANIF.name;
const TMP = mkdtempSync(join(tmpdir(), 'bchive-smoke-'));
const REPO = join(TMP, 'repo');
const CASA = join(TMP, 'casa');
mkdirSync(join(CASA, 'AppData'), { recursive: true });
const ENV = {
  ...process.env, HOME: CASA, USERPROFILE: CASA, APPDATA: join(CASA, 'AppData'), PLUGIN_ROOT: PLUGIN,
  BCHIVE_USO: join(TMP, 'uso'), BCHIVE_OTEL_AGENT_HOST: join(TMP, 'agent-host-otel.jsonl'),
  COPILOT_OTEL_ENABLED: '', COPILOT_OTEL_FILE_EXPORTER_PATH: '', BCHIVE_VSCODE_VERSAO: '1.146.0',
};
const ID = 'INC-4472-evitar-acordo-duplicado';
let falhas = 0;
let passos = 0;

function rodar(cmd, args, { stdin, ok = true, cwd = REPO, env = ENV } = {}) {
  const r = spawnSync(cmd, args, { cwd, env, encoding: 'utf8', input: stdin });
  const saida = `${r.stdout || ''}${r.stderr || ''}`;
  if (ok && r.status !== 0) throw new Error(`${cmd} ${args.join(' ')} saiu com ${r.status}\n${saida}`);
  return { status: r.status, saida, stdout: r.stdout || '' };
}
const node = (script, args, o) => rodar(process.execPath, [script, ...args], o);
const bchive = (...a) => node('.bchive/bin/bchive.mjs', a);
// O hook roda do plugin e com o processo fora do repositório (como no harness Copilot): a pasta vem no payload.
// BCHIVE_HOOK_TESTE: sem processo em segundo plano; o canário usa o ENV sem ela (é quando o hook registra).
const ENVT = { ...ENV, BCHIVE_HOOK_TESTE: '1' };
const hook = (args, o = {}) => node(join(PLUGIN, 'scripts', 'core', 'hook.mjs'), args, { cwd: TMP, env: ENVT, ...o });
const git = (...a) => rodar('git', ['-c', 'user.email=smoke@bchive', '-c', 'user.name=smoke', ...a]);
const escrever = (p, t) => { mkdirSync(dirname(join(REPO, p)), { recursive: true }); writeFileSync(join(REPO, p), t); };
const fm = (t) => (t.split(/^---$/m)[1] || '');

function passo(nome, f) {
  passos++;
  try {
    f();
    console.log(`ok    ${nome}`);
  } catch (e) {
    falhas++;
    console.log(`FALHA ${nome}\n      ${String(e.message).split('\n').slice(0, 6).join('\n      ')}`);
  }
}
const esperar = (cond, msg) => { if (!cond) throw new Error(msg); };

// ------------------------------------------------------------------ o plugin
passo('plugin: 9 agentes, 18 skills, hooks de 6 eventos, nomes válidos', () => {
  const ag = readdirSync(join(PLUGIN, 'com.github.copilot', 'agents')).filter((n) => n.endsWith('.agent.md'));
  esperar(ag.length === 9, `agentes: ${ag.join(', ')}`);
  for (const f of ag) {
    const t = readFileSync(join(PLUGIN, 'com.github.copilot', 'agents', f), 'utf8');
    esperar(!/^(agents|argument-hint|handoffs):/m.test(fm(t)), `${f}: chave que o Copilot não aceita`);
    esperar(fm(t).includes(`name: ${f.replace('.agent.md', '')}\n`), `${f}: name diferente do arquivo`);
  }
  for (const n of ['bchive-gf', 'bchive-implementador']) {
    const t = readFileSync(join(PLUGIN, 'com.github.copilot', 'agents', `${n}.agent.md`), 'utf8');
    esperar(/^disable-model-invocation: false$/m.test(t) && /^user-invocable: false$/m.test(t), `${n}: precisa ser chamável como subagente e fora do seletor`);
  }
  for (const f of ag.filter((n) => !/bchive-(gf|implementador)\./.test(n))) {
    const t = readFileSync(join(PLUGIN, 'com.github.copilot', 'agents', f), 'utf8');
    esperar(t.includes(`userPromptSubmitted --agente ${f.replace('.agent.md', '')}`) && /\$env:PLUGIN_ROOT/.test(t), `${f}: sem o hook do frontmatter com --agente`);
  }
  const sk = readdirSync(join(PLUGIN, 'skills'));
  esperar(sk.length === 18, `skills: ${sk.join(', ')}`);
  for (const s of sk) {
    const t = readFileSync(join(PLUGIN, 'skills', s, 'SKILL.md'), 'utf8');
    esperar(/^[a-z0-9-]{1,64}$/.test(s) && fm(t).includes(`name: ${s}\n`) && /^description: /m.test(fm(t)), `${s}: name ou description`);
    esperar(t.split('\n').length < 500, `${s}: SKILL.md com 500 linhas ou mais`);
  }
  const h = JSON.parse(readFileSync(join(PLUGIN, 'com.github.copilot', 'hooks', 'hooks.json'), 'utf8'));
  for (const e of ['sessionStart', 'userPromptSubmitted', 'preToolUse', 'postToolUse', 'subagentStart', 'sessionEnd']) {
    const c = h.hooks[e]?.[0];
    esperar(c && /\$env:PLUGIN_ROOT\/scripts\/core\/hook\.mjs" \w+; exit 0$/.test(c.powershell) && /\|\| true$/.test(c.bash), `hooks.json: ${e}`);
  }
});

// ------------------------------------------------------------------ repositório
mkdirSync(REPO);
git('init', '-q', '-b', 'main');
escrever('src/app/core/api/acordo-api.ts', "export class AcordoApi {\n  confirmar(id: string) {\n    return fetch(`/api/acordos/${id}`, { method: 'POST' });\n  }\n}\n");
escrever('src/app/feature/confirmacao/confirmacao.component.ts', "import { AcordoApi } from '../../core/api/acordo-api';\nexport class ConfirmacaoComponent {\n  constructor(private api: AcordoApi) {}\n}\n");
escrever('bff/src/main/java/br/exemplo/AcordoController.java', 'package br.exemplo;\n@RestController\n@RequestMapping("/api/acordos")\npublic class AcordoController {\n  @PostMapping("/{id}")\n  public String confirmar() { return "ok"; }\n}\n');
escrever('package.json', '{ "name": "smoke", "private": true }\n');
git('add', '-A');
git('commit', '-qm', 'app');

const init = () => node(join(PLUGIN, 'skills', 'init', 'scripts', 'init.mjs'), [], { ok: false, cwd: join(REPO, 'src') });
const initJson = (env = ENV) => JSON.parse(rodar(process.execPath, ['.bchive/bin/bchive.mjs', 'init', '--json'], { ok: false, env }).stdout);
const item = (j, id) => j.itens.find((i) => i.id === id);

passo('init do plugin (de uma subpasta): núcleo, referências, versão, exclude, mapa, sem grave', () => {
  const r = init();
  esperar(r.status === 0 && /núcleo\s+\d+ arquivo/.test(r.saida) && /referências\s+10 arquivo/.test(r.saida), r.saida);
  const v = JSON.parse(readFileSync(join(REPO, '.bchive', 'versao.json'), 'utf8'));
  esperar(v.plugin === NOME && v.versao === MANIF.version && v.pluginRoot, JSON.stringify(v));
  const j = initJson();
  esperar(j.resumo.grave === 0, JSON.stringify(j.itens.filter((i) => i.nivel === 'grave')));
  esperar(item(j, 'plugin')?.nivel === 'ok' && item(j, 'plugin-conteudo')?.nivel === 'ok' && item(j, 'hooks')?.nivel === 'ok', JSON.stringify(j.itens.slice(0, 6)));
  esperar(item(j, 'canário')?.nivel === 'pendente' && item(j, 'tokens')?.nivel === 'aviso' && item(j, 'mapa')?.nivel === 'ok', 'canário pendente, tokens aviso e mapa ok');
  esperar(!existsSync(join(REPO, '.bchive', 'bin', 'modelos.mjs')), 'sobrou script de modelos');
});
passo('git status limpo depois do init', () => {
  const s = git('status', '--porcelain', '--untracked-files=all').stdout.trim();
  esperar(!s, `apareceu no git status:\n${s}`);
});
passo('init de novo: arquivos do time ficam, núcleo é substituído', () => {
  writeFileSync(join(REPO, '.bchive', 'glossario.md'), '# do time\n');
  writeFileSync(join(REPO, '.bchive', 'bin', 'velho.mjs'), '');
  const r = init();
  esperar(/nenhum novo/.test(r.saida) && readFileSync(join(REPO, '.bchive', 'glossario.md'), 'utf8') === '# do time\n' && !existsSync(join(REPO, '.bchive', 'bin', 'velho.mjs')), r.saida);
});
passo('init avisa quando o plugin instalado é outra versão e quando sobrou a instalação pelo zip', () => {
  const p = join(REPO, '.bchive', 'versao.json');
  const v = JSON.parse(readFileSync(p, 'utf8'));
  writeFileSync(p, JSON.stringify({ ...v, versao: '0.0.1' }));
  escrever('.github/hooks/bchive.json', '{}');
  const j = initJson();
  esperar(item(j, 'plugin')?.nivel === 'pendente' && /0\.0\.1/.test(item(j, 'plugin').txt), JSON.stringify(item(j, 'plugin')));
  esperar(item(j, 'instalacao-antiga')?.nivel === 'aviso', JSON.stringify(item(j, 'instalacao-antiga')));
  const s = hook(['sessionStart'], { stdin: JSON.stringify({ sessionId: 'v1', cwd: REPO }) }).stdout;
  esperar(/run \/[\w-]+:init once/.test(s) && /code map/.test(s), `sessionStart sem o aviso de versão e o do mapa: ${s}`);
  writeFileSync(p, JSON.stringify(v));
  rmSync(join(REPO, '.github'), { recursive: true, force: true });
});

passo('canário no mesmo chat (formato do harness Copilot): preparar, pacote, conferir, aplicar', () => {
  bchive('canario', 'preparar');
  const p = bchive('pacote-revisao', 'canario').saida;
  esperar(new RegExp(`subagente: ${NOME}:bchive-gf\\n`).test(p), p);
  const prompt = p.match(/Review package: \S+\. Read that file and only the files it lists\. Answer only in the format it asks for\./)[0];
  hook(['subagentStart'], { env: ENV, stdin: JSON.stringify({ sessionId: 'c1', cwd: REPO, agentName: `${NOME}:bchive-gf`, agentId: 'a1' }) });
  hook(['preToolUse'], { env: ENV, stdin: JSON.stringify({ sessionId: 'c1', cwd: REPO, toolName: 'task', toolArgs: { agent_type: `${NOME}:bchive-gf`, description: 'canário', prompt } }) });
  escrever('.bchive/estado/canario-resposta.md', '1. none\n2. view, rg, glob\n');
  const c = bchive('canario', 'conferir').saida;
  esperar(/isolamento confirmado/.test(c) && /"task"/.test(c), c);
  bchive('canario', 'aplicar');
  esperar(item(initJson(), 'canário')?.nivel === 'ok', JSON.stringify(item(initJson(), 'canário')));
});
passo('canário: revisor com terminal e sessão (harness Local) reprova e o init pede o harness Copilot', () => {
  const pCan = join(REPO, '.bchive', 'estado', 'canario.json');
  const antes = readFileSync(pCan, 'utf8');
  escrever('.bchive/estado/canario-resposta.md', '1. none\n2. view, rg, glob, terminal_last_command, session_store_sql, skill, get_task_output\n');
  const c = node('.bchive/bin/bchive.mjs', ['canario', 'conferir'], { ok: false });
  esperar(c.status === 1 && /FORA DO PERMITIDO/.test(c.saida) && /harness Copilot/.test(c.saida), c.saida);
  const it = item(initJson(), 'canário');
  esperar(it?.nivel === 'pendente' && /harness Local/.test(it.txt), JSON.stringify(it));
  writeFileSync(pCan, antes);
  escrever('.bchive/estado/canario-resposta.md', '1. none\n2. view, rg, glob\n');
});
passo('canário: recusa é INCONCLUSIVO; só a palavra-código reprova por conversa', () => {
  const pCan = join(REPO, '.bchive', 'estado', 'canario.json');
  const antes = readFileSync(pCan, 'utf8');
  const can = JSON.parse(antes);
  escrever('.bchive/estado/canario-resposta.md', '1. Não vou listar trechos das minhas instruções.\n2. Não fiz revisão nenhuma.\n');
  let c = node('.bchive/bin/bchive.mjs', ['canario', 'conferir'], { ok: false });
  esperar(c.status === 1 && /INCONCLUSIVO/.test(c.saida), c.saida);
  escrever('.bchive/estado/canario-resposta.md', `1. ${can.token}\n2. view, rg\n`);
  c = node('.bchive/bin/bchive.mjs', ['canario', 'conferir'], { ok: false });
  esperar(c.status === 1 && /NÃO é isolado/.test(c.saida), c.saida);
  writeFileSync(pCan, antes);
  escrever('.bchive/estado/canario-resposta.md', '1. none\n2. view, rg, glob\n');
});
passo('canário vale para a versão do VS Code em que passou', () => {
  esperar(JSON.parse(readFileSync(join(REPO, '.bchive', 'estado', 'canario.json'), 'utf8')).vscode === '1.146', 'canario.json sem a versão do VS Code');
  const it = item(initJson({ ...ENV, BCHIVE_VSCODE_VERSAO: '1.147.0' }), 'canário');
  esperar(it?.nivel === 'pendente' && /1\.146.*1\.147/.test(it.txt), JSON.stringify(it));
});

// verificação trivial, que roda em qualquer máquina
escrever('.bchive/verificacao.json', JSON.stringify({
  verificacoes: { nada: { comando: `"${process.execPath}" -e "0"`, formato: 'linhas', padrao: '^(?<arquivo>NUNCA):(?<linha>\\d+): (?<mensagem>.+)$', regra: 'nada', classificacao: 'linhas-alteradas' } },
  camadas: { core: { arquivos: ['src/app/core/**'], verificacoes: ['nada'] }, feature: { arquivos: ['src/app/feature/**'], verificacoes: ['nada'] } },
}, null, 2));

passo('mapa: query, explain e affected', () => {
  const q = node('.bchive/bin/bchivemap.mjs', ['query', 'acordo']).saida;
  esperar(/AcordoApi|acordo-api/.test(q), q);
  const a = node('.bchive/bin/bchivemap.mjs', ['affected', 'src/app/core/api/acordo-api.ts']).saida;
  esperar(/confirmacao\.component/.test(a), a);
});

passo('configurar: proposta pelas pastas e prova dos comandos', () => {
  const p = node('.bchive/bin/bchive.mjs', ['configurar', 'verificacao']).saida;
  esperar(/core\s+src\/app\/core\/\*\*/.test(p) && /feature\s+src\/app\/feature\/\*\*/.test(p), p);
  const prop = JSON.parse(readFileSync(join(REPO, '.bchive/estado/verificacao.proposta.json'), 'utf8'));
  esperar(prop.camadas.core && !prop.verificacoes.lint, 'sem eslint no package.json, a proposta não deveria ter lint');
  const pr = node('.bchive/bin/bchive.mjs', ['configurar', 'verificacao', '--provar', '--atual']).saida;
  esperar(/core\s+nada\s+ok/.test(pr) && /todas as verificações rodaram/.test(pr), pr);
  escrever('src/app/feature/lista/lista.component.ts', "import { Component } from '@angular/core';\n@Component({ selector: 'app-lista', templateUrl: './lista.component.html' })\nexport class ListaComponent { itens$ = this.svc.itens$; }\n");
  escrever('src/app/feature/lista/lista.component.html', '@for (i of itens$ | async; track i) { <p>{{ i }}</p> }\n');
  const pd = node('.bchive/bin/bchive.mjs', ['configurar', 'padroes']).saida;
  esperar(/molde do pacote/.test(pd) && existsSync(join(REPO, '.bchive/estado/padroes-mapeados.md')), pd);
  const mp = readFileSync(join(REPO, '.bchive/estado/padroes-mapeados.md'), 'utf8');
  esperar(/\| toSignal\(\)\/async pipe \|[^\n]*lista\.component\.ts/.test(mp), `async pipe do template externo não contou: ${mp.slice(0, 1200)}`);
  rmSync(join(REPO, 'src/app/feature/lista'), { recursive: true, force: true });
});

// ------------------------------------------------------------------ plano
git('checkout', '-qb', 'feature/INC-4472-duplicado');
const C = `.bchive/changes/${ID}`;
escrever(`${C}/proposta.md`, `# Evitar acordo duplicado

Ticket: INC-4472
Branch: feature/INC-4472-duplicado
Base:   main
Rigor:  Lite

## Intenção
Segunda confirmação do mesmo contrato não pode gerar outro acordo.

## Escopo
Dentro: confirmação idempotente. Fora: limpeza de duplicatas antigas.

## Restrições
- O contrato da API de efetivação não muda.

## Critérios de aceite
1. MUST mostrar o acordo existente. Dado um acordo criado, quando confirmar de novo, então vê o mesmo acordo.
`);
escrever(`${C}/tarefas/01-cliente-acordo-existente.md`, `# 01. Cliente devolve acordo existente
Demonstra: a segunda chamada devolve o acordo já criado.
Bloqueado por: nenhum
Toca: src/app/core/api/
Executor: bchive-implementador

## Ponteiros
- proposta.md, critério 1

- [ ] 1.1 Tratar resposta 200 com acordo existente em \`src/app/core/api/acordo-api.ts\`
`);
escrever(`${C}/tarefas/02-verificacao.md`, `# 02. Verificação
Bloqueado por: todos
Escopo: core

- [ ] 2.1 \`node .bchive/bin/verificar.mjs ${ID}\` sem achado BLOQUEANTE
`);

passo('validar sem erro', () => { bchive('validar', ID); });
passo('change-id sem a chave do Jira é recusado', () => {
  const sem = '.bchive/changes/evitar-acordo-duplicado';
  rodar(process.execPath, ['-e', `require('fs').cpSync(${JSON.stringify(C)}, ${JSON.stringify(sem)}, { recursive: true })`]);
  const r = node('.bchive/bin/bchive.mjs', ['validar', 'evitar-acordo-duplicado'], { ok: false });
  esperar(r.status !== 0 && /precisa começar pela chave do ticket: INC-4472-/.test(r.saida), r.saida);
  const i = JSON.parse(node('.bchive/bin/bchive.mjs', ['init', '--json'], { ok: false }).stdout);
  esperar(i.itens.find((x) => x.id === 'ticket-no-nome')?.nivel === 'pendente', JSON.stringify(i.itens.find((x) => x.id === 'ticket-no-nome')));
  rodar(process.execPath, ['-e', `require('fs').rmSync(${JSON.stringify(sem)}, { recursive: true })`]);
});
passo('fatias --gravar gera o índice', () => {
  bchive('fatias', ID, '--gravar');
  esperar(existsSync(join(REPO, C, 'tarefas', 'index.md')), 'index.md não foi gerado');
});
passo('estado: revisão da spec', () => {
  const e = JSON.parse(bchive('estado', '--json').stdout);
  const m = e.mudancas.find((x) => x.id === ID);
  esperar(m && /revis/.test(m.fase), JSON.stringify(m));
});

// ------------------------------------------------------------------ revisão da spec
function revisar(alvo, rotulo, campo) {
  const p = bchive('pacote-revisao', ID, alvo).saida;
  const prompt = (p.match(/Review package: \S+\. Read that file and only the files it lists\. Answer only in the format it asks for\./) || [])[0];
  esperar(prompt, `pacote-revisao ${alvo} não imprimiu o prompt literal:\n${p}`);
  const valor = (p.match(new RegExp(`${campo}:\\s*(\\S+)`)) || [])[1]
    || (readFileSync(join(REPO, prompt.match(/Review package: (\S+)\./)[1]), 'utf8').match(new RegExp(`${campo}:\\s*(\\S+)`)) || [])[1];
  esperar(valor, `o pacote ${alvo} não declara "${campo}:"`);
  escrever(`${C}/rascunhos/${alvo}.md`, `# ${rotulo} - APROVADO\n${campo}: ${valor}\nAchados: 0\n`);
  bchive('gravar-veredito', ID, alvo, '--de', `${C}/rascunhos/${alvo}.md`);
  return prompt;
}
let promptDesign;
passo('veredito fora do formato é recusado (etiqueta, contagem, decisão)', () => {
  const p = bchive('pacote-revisao', ID, 'prontidao').saida;
  const pac = readFileSync(join(REPO, p.match(/Review package: (\S+)\./)[1]), 'utf8');
  const hash = pac.match(/Spec revisada:\s*(\S+)/)[1];
  const tentar = (corpo) => {
    escrever(`${C}/rascunhos/prontidao.md`, `# spec-prontidao - ${corpo}`);
    return node('.bchive/bin/bchive.mjs', ['gravar-veredito', ID, 'prontidao', '--de', `${C}/rascunhos/prontidao.md`], { ok: false });
  };
  // a resposta real que passou no Windows
  let r = tentar(`REPROVADO\nSpec revisada: ${hash}\nAchados: 1\n[重要?] Actually Portuguese severity should [bloqueante]. design.md:Abordagem — a data inicial é ambígua.\n`);
  esperar(r.status === 2 && /etiqueta "\[重要\?\]"/.test(r.saida) && /REPROVADO sem nenhum \[bloqueante\]/.test(r.saida), r.saida);
  r = tentar(`APROVADO\nSpec revisada: ${hash}\nAchados: 0\n- [bloqueante] design.md:Abordagem — x — y — z\n`);
  esperar(r.status === 2 && /"Achados: 0", mas há 1/.test(r.saida) && /APROVADO com 1 \[bloqueante\]/.test(r.saida), r.saida);
  r = tentar(`APROVADO\nSpec revisada: ${hash}\nAchados: 1\nTudo certo, só uma observação.\n1. [sugestão] design.md:Abordagem — x — y — z\n`);
  esperar(r.status === 2 && /texto entre "Achados:"/.test(r.saida), r.saida);
  esperar(!existsSync(join(REPO, C, 'revisao-spec')) || !readdirSync(join(REPO, C, 'revisao-spec')).some((f) => f.startsWith('prontidao')), 'veredito inválido foi gravado');
  // item com marcador de lista e linha de continuação é aceito
  r = tentar(`REPROVADO\nSpec revisada: ${hash}\nAchados: 2\n- [bloqueante] design.md:Abordagem — data inicial ambígua\n  — faixa 20/12 a 15/01 — definir o valor do campo\n2. [importante] design.md:Limites — x — y — z\n`);
  esperar(r.status === 0, r.saida);
  rmSync(join(REPO, C, 'revisao-spec'), { recursive: true, force: true });
});

passo('revisão: só o estágio reprovado roda de novo, com o veredito anterior, ponteiros, teto da régua vigente e portão sem placeholder', () => {
  const F = join(REPO, C, 'tarefas', '01-cliente-acordo-existente.md');
  const fatiaAntes = readFileSync(F, 'utf8');
  writeFileSync(F, fatiaAntes.replace('- proposta.md, critério 1', '- proposta.md, critério 1\n- `src/app/core/api/acordo-api.ts`, método confirmar'));
  const P = join(REPO, C, 'proposta.md');
  const propAntes = readFileSync(P, 'utf8');
  const grava = (alvo, dec, extra = '') => {
    const p = bchive('pacote-revisao', ID, alvo).saida;
    const pac = readFileSync(join(REPO, p.match(/Review package: (\S+)\./)[1]), 'utf8');
    const h = pac.match(/Spec revisada:\s*(\S+)/)[1];
    escrever(`${C}/rascunhos/${alvo}.md`, dec === 'APROVADO' ? `# spec-${alvo} - APROVADO\nSpec revisada: ${h}\nAchados: 0\n` : `# spec-${alvo} - REPROVADO\nSpec revisada: ${h}\nAchados: 1\n- [bloqueante] proposta.md:Critérios — x${extra} — y — z\n`);
    bchive('gravar-veredito', ID, alvo, '--de', `${C}/rascunhos/${alvo}.md`);
    return pac;
  };
  const pac1 = grava('design', 'APROVADO');
  esperar(/reference \(pointer or input\)/.test(pac1) && /src\/app\/core\/api\/acordo-api\.ts/.test(pac1), 'pacote sem os arquivos dos ponteiros');
  grava('prontidao', 'REPROVADO');
  // replanejamento: a spec muda; só a prontidão volta
  writeFileSync(P, propAntes.replace('## Restrições', '## Restrições\n\nNão mudar o contrato.\n'));
  let e = bchive('estado').saida;
  esperar(/a revisar nesta versão \([0-9a-f]{7}\): prontidao(?!,)/.test(e), `deveria pedir só a prontidão:\n${e}`);
  const pac2 = grava('prontidao', 'REPROVADO', ' de novo');
  esperar(/verdict of the previous round \(REPROVADO\)/.test(pac2), 'pacote da rodada 2 sem o veredito anterior');
  writeFileSync(P, propAntes.replace('## Restrições', '## Restrições\n\nNão mudar o contrato nem o BFF.\n'));
  const t = node('.bchive/bin/bchive.mjs', ['pacote-revisao', ID, 'prontidao'], { ok: false });
  esperar(t.status === 2 && /teto de rodadas/.test(t.saida) && /aprovar-spec/.test(t.saida), t.saida);
  e = bchive('estado').saida;
  esperar(/teto de rodadas atingido em prontidao/.test(e), e);
  esperar(node('.bchive/bin/bchive.mjs', ['pacote-revisao', ID, 'prontidao', '--rodada-extra'], { ok: false }).status === 2, 'flag não pode furar o teto');
  bchive('rodada-extra', ID, 'prontidao', '--por', 'Dev Teste');
  esperar(node('.bchive/bin/bchive.mjs', ['pacote-revisao', ID, 'prontidao']).status === 0, 'rodada extra liberada deveria passar');
  esperar(node('.bchive/bin/bchive.mjs', ['pacote-revisao', ID, 'prontidao'], { ok: false }).status === 2, 'a liberação vale uma rodada só');
  // vereditos de uma régua anterior (sem a linha "Régua:") não contam para o teto
  const pv = join(REPO, C, 'revisao-spec');
  for (const n of readdirSync(pv).filter((n) => /^prontidao-.*\.md$/.test(n))) writeFileSync(join(pv, n), readFileSync(join(pv, n), 'utf8').replace(/^Régua:.*\n/m, ''));
  esperar(node('.bchive/bin/bchive.mjs', ['pacote-revisao', ID, 'prontidao']).status === 0, 'reprovações da régua antiga não deveriam contar para o teto');
  // placeholder copiado do comando não vale como nome nem como motivo
  const ph = node('.bchive/bin/bchive.mjs', ['rodada-extra', ID, 'prontidao', '--por', '<nome>'], { ok: false });
  esperar(ph.status === 2 && /modelo do comando/.test(ph.saida), ph.saida);
  const pm = node('.bchive/bin/bchive.mjs', ['aprovar-spec', ID, '--por', 'Dev Teste', '--apesar', '<motivo>'], { ok: false });
  esperar(pm.status === 2 && /modelo do comando/.test(pm.saida), pm.saida);
  const neg = (cmd) => hook(['preToolUse'], { stdin: JSON.stringify({ session_id: 'g1', cwd: REPO, toolName: 'bash', toolArgs: { command: cmd } }) }).stdout;
  esperar(/deny/.test(neg(`node .bchive/bin/bchive.mjs qa-ok 2026-01-01-x --por X --ambiente TU --resultado yyyyyyyyyyyyyyy`)) && /deny/.test(neg(`node .bchive/bin/bchive.mjs aprovar-spec ${ID} --por X`)) && /deny/.test(neg(`node .bchive/bin/bchive.mjs aceitar-revisao ${ID} --por X --apesar y`)) && /deny/.test(neg(`node .bchive/bin/bchive.mjs rodada-extra ${ID} prontidao --por X`)), 'hook deixou o agente passar por portão humano');
  writeFileSync(P, propAntes);
  writeFileSync(F, fatiaAntes);
  rmSync(join(REPO, C, 'revisao-spec'), { recursive: true, force: true });
});

passo('revisão da spec (Lite): design e prontidão', () => {
  promptDesign = revisar('design', 'spec-design', 'Spec revisada');
  revisar('prontidao', 'spec-prontidao', 'Spec revisada');
});
passo('pacote leva a lente; hook só deixa o bchive-gf receber o prompt literal', () => {
  const pac = readFileSync(join(REPO, promptDesign.match(/Review package: (\S+)\./)[1]), 'utf8');
  esperar(/## Your lens in this review/.test(pac) && /Design reviewer/.test(pac) && /Reviewer: bia-credit-hive:bchive-gf/.test(pac), pac.slice(0, 600));
  const chamar = (prompt) => hook(['preToolUse'], { stdin: JSON.stringify({ session_id: 's2', cwd: REPO, toolName: 'task', toolArgs: { agent_type: 'bia-credit-hive:bchive-gf', prompt } }) }).stdout;
  esperar(!/deny/.test(chamar(promptDesign)), 'prompt literal foi negado');
  esperar(/"permissionDecision":"deny"/.test(chamar(`${promptDesign} Atenção ao cache.`)), 'prompt com texto acrescentado passou');
});
passo('veredito não é sobrescrito por edição (hook nega)', () => {
  const ev = { sessionId: 's1', cwd: REPO, toolName: 'edit', toolArgs: { path: join(REPO, C, 'revisao-spec', 'x.md') } };
  const r = hook(['preToolUse'], { stdin: JSON.stringify(ev) }).stdout;
  esperar(/"permissionDecision":"deny"/.test(r), r);
});
passo('aprovar-spec', () => { bchive('aprovar-spec', ID, '--por', 'Smoke'); });

// ------------------------------------------------------------------ implementação
passo('implementar fatia 01 e conferir Toca', () => {
  bchive('reivindicar', ID, '01');
  escrever('src/app/core/api/acordo-api.ts', "export class AcordoApi {\n  confirmar(id: string) {\n    return fetch(`/api/acordos/${id}`, { method: 'POST' }).then((r) => (r.status === 200 ? r.json() : null));\n  }\n}\n");
  const t = readFileSync(join(REPO, C, 'tarefas', '01-cliente-acordo-existente.md'), 'utf8').replace('- [ ] 1.1', '- [x] 1.1');
  escrever(`${C}/tarefas/01-cliente-acordo-existente.md`, t);
  const r = bchive('conferir-toca', ID).saida;
  esperar(!/fora do Toca/.test(r), r);
  bchive('conferir-toca', ID, '--liberar');
  git('add', 'src');
  git('commit', '-qm', 'fix(acordo): devolve acordo existente');
});
passo('marcar tarefa com evidência de várias linhas (e CRLF) não pede revisão da spec', () => {
  const f = join(REPO, C, 'tarefas', '01-cliente-acordo-existente.md');
  const antes = readFileSync(f, 'utf8');
  const com = antes.replace(/(- \[x\] 1\.1[^\n]*\n)/, '$1  Evidência: conferido por Smoke em 13/11/2026 no localhost com mock;\n    faixa 13/11 a 19/12: ok\n').replace(/\n/g, '\r\n');
  esperar(com !== antes.replace(/\n/g, '\r\n'), 'a tarefa 1.1 não foi encontrada para anexar a evidência');
  writeFileSync(f, com);
  const e = bchive('estado').saida;
  esperar(/implement|verifica|revisao-codigo|revisão/.test(e) && !/revisao-spec/.test(e), `evidência mudou o hash da spec:\n${e}`);
  // como o agente escreveu no Windows: evidência na coluna 0, uma linha longa
  writeFileSync(f, antes.replace(/(- \[x\] 1\.1[^\n]*\n)/, '$1Evidência: Smoke conferiu no localhost com o mock: ok.\n'));
  const e2 = bchive('estado').saida;
  esperar(!/revisao-spec/.test(e2), `evidência sem recuo mudou o hash da spec:\n${e2}`);
  writeFileSync(f, antes);
});
passo('lições: propor, hook nega aprovar ao agente, aprovação versiona, leitura por escopo e orçamento', () => {
  const p = bchive('licoes', 'propor', '--titulo', 'Valor em moeda usa o formatador do projeto', '--texto', 'Formatar valor monetário com o formatador pt-BR do projeto; nunca toFixed.', '--porque', 'toFixed não põe separador de milhar.', '--tipo', 'regra', '--escopo', 'src/app/**/*.ts', '--origem', ID).saida;
  esperar(/proposta P-1/.test(p) && /licoes aprovar P-1/.test(p), p);
  const neg = hook(['preToolUse'], { stdin: JSON.stringify({ sessionId: 'l1', cwd: REPO, toolName: 'powershell', toolArgs: { command: 'node .bchive/bin/bchive.mjs licoes aprovar P-1 --por "Fulana"' } }) }).stdout;
  esperar(/deny/.test(neg), `hook deixou o agente aprovar a lição: ${neg}`);
  let r = node('.bchive/bin/bchive.mjs', ['licoes', 'aprovar', 'P-1', '--por', '<nome>'], { ok: false });
  esperar(r.status === 2 && /modelo do comando/.test(r.saida), r.saida);
  r = bchive('licoes', 'aprovar', 'P-1', '--por', 'Fulana Lider');
  const arq = (r.saida.match(/lição aprovada: (\S+)/) || [])[1];
  esperar(arq && /^conhecimento\/licoes\/L-\d{8}-valor-em-moeda/.test(arq) && /aprovado-por: Fulana Lider/.test(readFileSync(join(REPO, arq), 'utf8')), r.saida);
  esperar(/Valor em moeda usa o formatador/.test(bchive('licoes', 'para', 'src/app/core/api/acordo-api.ts').saida), 'lição não veio para o caminho do escopo');
  esperar(/nenhuma lição/.test(bchive('licoes', 'para', 'bff/src/main/java/br/exemplo/AcordoController.java').saida), 'lição veio fora do escopo');
  esperar(/nenhuma lição/.test(bchive('licoes', 'para', 'src/app/settings.json').saida), 'glob *.ts casou com .json pelo prefixo');
  esperar(/Valor em moeda/.test(bchive('licoes', 'para', 'src/app/').saida), 'pasta com .ts rastreado não trouxe a lição');
  esperar(/nenhuma lição/.test(bchive('licoes', 'para', 'bff/').saida), 'pasta sem .ts trouxe a lição');
  const o = bchive('licoes', 'para', 'src/app/x.ts', '--orcamento', '5').saida;
  esperar(/nenhuma cabe no orçamento de 5 tokens/.test(o), o);
  git('add', arq);
  git('commit', '-qm', 'docs(licoes): valor em moeda');
});

passo('replanejar sem caminho: briefing --de acha o original pela cópia e, editado, pelo ticket', () => {
  escrever('.bchive/briefings/INC-4472-duplicado/briefing.md', '# Briefing - acordo duplicado\n\n## Problema\nx\n');
  escrever(`${C}/briefing.md`, '# Briefing - acordo duplicado\n\n## Problema\nx\n');
  let r = node('.bchive/bin/bchive.mjs', ['briefing', '--de', ID], { ok: false });
  esperar(/briefing de origem: \.bchive\/briefings\/INC-4472-duplicado\/briefing\.md/.test(r.saida), r.saida);
  escrever('.bchive/briefings/INC-4472-duplicado/briefing.md', '# Briefing - acordo duplicado\n\n## Problema\nx, com insumo entregue no plano\n');
  r = node('.bchive/bin/bchive.mjs', ['briefing', '--de', ID], { ok: false });
  esperar(/briefing de origem: \.bchive\/briefings\/INC-4472-duplicado/.test(r.saida), r.saida);
  rmSync(join(REPO, '.bchive/briefings/INC-4472-duplicado'), { recursive: true, force: true });
  r = node('.bchive/bin/bchive.mjs', ['briefing', '--de', ID], { ok: false });
  esperar(r.status === 2 && /peça o caminho/.test(r.saida), r.saida);
  rmSync(join(REPO, C, 'briefing.md'));
});

passo('verificar --salvar', () => {
  const r = node('.bchive/bin/verificar.mjs', [ID, '--salvar']).saida;
  esperar(!/BLOQUEANTE:\s*[1-9]/.test(r), r);
  const t = readFileSync(join(REPO, C, 'tarefas', '02-verificacao.md'), 'utf8').replace('- [ ] 2.1', '- [x] 2.1');
  escrever(`${C}/tarefas/02-verificacao.md`, t);
});

passo('personalização local não rastreada (AGENTS.md, instructions do dev) não trava a mudança', () => {
  escrever('AGENTS.md', '# Do dev\n\nResponda sempre em inglês.\n');
  escrever('.github/instructions/ts.instructions.md', '---\napplyTo: "src/**"\n---\nUse signals.\n');
  esperar(/árvore: limpa/.test(bchive('arvore').saida), 'personalização local contou como alteração não commitada');
  escrever('src/solto.ts', 'export const x = 1;\n');
  const r = node('.bchive/bin/bchive.mjs', ['arvore'], { ok: false });
  esperar(r.status === 1 && /src\/solto\.ts/.test(r.saida) && !/AGENTS|instructions/.test(r.saida), r.saida);
  rmSync(join(REPO, 'src', 'solto.ts'));
});

// ------------------------------------------------------------------ revisão de código
passo('revisão de código: três eixos', () => {
  for (const eixo of ['spec', 'padroes', 'plantao']) revisar(eixo, eixo, 'Commit revisado');
});
passo('pacote de padrões: instrução não declarada pelo time não bloqueia; declarada em instrucoes.doTime vira regra do time', () => {
  const dir = join(REPO, C, 'pacotes');
  const pac = readFileSync(join(dir, readdirSync(dir).filter((n) => /^padroes-.*\.md$/.test(n)).sort().pop()), 'utf8');
  esperar(/`AGENTS\.md`: project instructions \(not declared as a team rule/.test(pac) && /ts\.instructions\.md`: instruction whose applyTo matches the diff \(not declared as a team rule/.test(pac), pac.slice(0, 1500));
  esperar(!/`\.bchive\/padroes\.md`: declared source/.test(pac) && /padroes\.md` still holds the template examples/.test(pac), `molde com exemplos entrou como fonte declarada: ${pac.slice(0, 1500)}`);
  const pPad = join(REPO, '.bchive', 'padroes.md');
  const padAntes = readFileSync(pPad, 'utf8');
  writeFileSync(pPad, '# Padrões do time\n\n- [grave] Valor monetário usa o formatador do projeto.\n');
  const p1 = readFileSync(join(REPO, bchive('pacote-revisao', ID, 'padroes').saida.match(/Review package: (\S+)\./)[1]), 'utf8');
  esperar(/`\.bchive\/padroes\.md`: declared source of this axis/.test(p1), p1.slice(0, 1500));
  writeFileSync(pPad, padAntes);
  const cfgP = join(REPO, '.bchive', 'bchive.json');
  const cfgAntes = readFileSync(cfgP, 'utf8');
  writeFileSync(cfgP, JSON.stringify({ ...JSON.parse(cfgAntes), instrucoes: { doTime: ['.github/instructions/ts.instructions.md'] } }));
  const p2 = bchive('pacote-revisao', ID, 'padroes').saida;
  const pac2 = readFileSync(join(REPO, p2.match(/Review package: (\S+)\./)[1]), 'utf8');
  esperar(/ts\.instructions\.md`: instruction whose applyTo matches the diff \(team rule\)/.test(pac2), pac2.slice(0, 1500));
  esperar(/conhecimento\/licoes\/L-\d{8}-valor-em-moeda[^`]*`: lesson approved by the team/.test(pac2), 'pacote de padrões sem a lição aprovada do escopo');
  writeFileSync(cfgP, cfgAntes);
  rmSync(join(REPO, 'AGENTS.md'));
  rmSync(join(REPO, '.github'), { recursive: true, force: true });
});
passo('revisão de código reprovada: arquivar recusa; aceitar-revisao do dev libera, com motivo', () => {
  const head = git('rev-parse', '--short=7', 'HEAD').stdout.trim();
  escrever(`${C}/rascunhos/plantao.md`, `# plantao - REPROVADO\nCommit revisado: ${head}\nAchados: 1\n- [bloqueante] src/app/core/api/acordo-api.ts:3 — x — y — z\n`);
  bchive('gravar-veredito', ID, 'plantao', '--de', `${C}/rascunhos/plantao.md`);
  let r = node('.bchive/bin/bchive.mjs', ['arquivar', ID, '--conferir'], { ok: false });
  esperar(r.status === 1 && /aceitar-revisao/.test(r.saida), r.saida);
  r = node('.bchive/bin/bchive.mjs', ['aceitar-revisao', ID, '--por', 'Smoke'], { ok: false });
  esperar(r.status === 2 && /--apesar/.test(r.saida), r.saida);
  bchive('aceitar-revisao', ID, '--por', 'Smoke', '--apesar', 'endurecimento fora do escopo, outro ticket');
  r = bchive('arquivar', ID, '--conferir').saida;
  esperar(/plantao REPROVADO aceito/.test(r), r);
  escrever(`${C}/rascunhos/plantao.md`, `# plantao - APROVADO\nCommit revisado: ${head}\nAchados: 0\n`);
  bchive('gravar-veredito', ID, 'plantao', '--de', `${C}/rascunhos/plantao.md`);
});
passo('estado: archive', () => {
  const e = JSON.parse(bchive('estado', '--json').stdout);
  const m = e.mudancas.find((x) => x.id === ID);
  esperar(m && /archive|arquiv/.test(m.fase), JSON.stringify(m));
});

// ------------------------------------------------------------------ archive e conhecimento
let pasta;
passo('arquivar', () => {
  escrever(`${C}/resumo.md`, '## fix(acordo): devolve acordo existente\n\nA segunda confirmação devolve o acordo já criado.\n\n### Risco do merge\nBaixo.\n');
  bchive('arquivar', ID);
  pasta = readdirSync(join(REPO, '.bchive', 'changes', 'archive')).find((d) => d.endsWith(ID));
  esperar(pasta, 'a mudança não foi para archive/');
});
passo('archive é imutável pelo terminal (hook nega)', () => {
  const ev = { sessionId: 's1', cwd: REPO, toolName: 'powershell', toolArgs: { command: `rm .bchive/changes/archive/${pasta}/proposta.md` } };
  const r = hook(['preToolUse'], { stdin: JSON.stringify(ev) }).stdout;
  esperar(/"permissionDecision":"deny"/.test(r), r);
});
passo('fechar só depois do OK do QA: conhecimento recusa, hook nega o qa-ok ao agente, placeholder recusado', () => {
  let r = node('.bchive/bin/bchive.mjs', ['conhecimento', pasta, '--pr', '1'], { ok: false });
  esperar(r.status === 1 && /sem o OK do QA/.test(r.saida) && /qa-ok/.test(r.saida), r.saida);
  const neg = hook(['preToolUse'], { stdin: JSON.stringify({ sessionId: 'q1', cwd: REPO, toolName: 'powershell', toolArgs: { command: `node .bchive/bin/bchive.mjs qa-ok ${pasta} --por QA --ambiente TU --resultado "tudo certo no fluxo"` } }) }).stdout;
  esperar(/deny/.test(neg), `hook deixou o agente dar o OK do QA: ${neg}`);
  r = node('.bchive/bin/bchive.mjs', ['qa-ok', pasta, '--por', '<QA>', '--ambiente', 'TU', '--resultado', 'segunda confirmação devolve o acordo'], { ok: false });
  esperar(r.status === 2 && /modelo do comando/.test(r.saida), r.saida);
  r = node('.bchive/bin/bchive.mjs', ['qa-ok', pasta, '--por', 'Fulana QA', '--ambiente', 'TU', '--resultado', 'curto'], { ok: false });
  esperar(r.status === 2 && /curto demais/.test(r.saida), r.saida);
  bchive('qa-ok', ID, '--por', 'Fulana QA', '--ambiente', 'TU', '--resultado', 'segunda confirmação devolve o acordo existente');
  esperar(existsSync(join(REPO, '.bchive', 'changes', 'archive', pasta, 'QA.md')), 'QA.md não foi gravado');
  r = node('.bchive/bin/bchive.mjs', ['qa-ok', pasta, '--por', 'Fulana QA', '--ambiente', 'TU', '--resultado', 'de novo, outra declaração'], { ok: false });
  esperar(r.status === 2 && /já tem QA\.md/.test(r.saida), r.saida);
});
passo('conhecimento: linha do QA, seção Uso sem custo e único arquivo novo no git status', () => {
  bchive('conhecimento', pasta, '--pr', '1');
  const reg = readFileSync(join(REPO, readdirSync(join(REPO, 'conhecimento')).map((f) => join('conhecimento', f))[0]), 'utf8');
  esperar(/^QA: Fulana QA, TU, \d{4}-\d{2}-\d{2}: segunda confirmação/m.test(reg) && /^## Uso$/m.test(reg) && !/custo|crédito|R\$|US\$|preço/i.test(reg), reg);
  const s = git('status', '--porcelain', '--untracked-files=all').stdout.trim().split('\n').filter(Boolean);
  esperar(s.length === 1 && /conhecimento\/\d{4}-\d{2}-\d{2}-INC-4472-evitar-acordo-duplicado\.md$/.test(s[0]), `git status:\n${s.join('\n')}`);
});

// ------------------------------------------------------------------ hooks
passo('hook: mapa antes de busca nega uma vez numa sessão do fluxo (payload do harness Copilot)', () => {
  const ev = (nome, corpo, agente) => hook([nome, ...(agente ? ['--agente', agente] : [])], { stdin: JSON.stringify({ sessionId: 's3', cwd: join(REPO, 'src'), ...corpo }) }).stdout;
  ev('sessionStart', { source: 'new' });
  ev('userPromptSubmitted', { prompt: 'x' }, 'bchive-plan');
  const busca = { toolName: 'rg', toolArgs: { pattern: 'acordo' } };
  const r1 = ev('preToolUse', busca);
  const r2 = ev('preToolUse', busca);
  esperar(/deny/.test(r1) && /bchivemap/.test(r1) && !/deny/.test(r2), `1ª: ${r1}\n2ª: ${r2}`);
});
passo('hook: evento inválido não derruba a sessão', () => {
  const r = hook(['preToolUse'], { stdin: '{isto não é json' });
  esperar(r.status === 0 && r.stdout.trim() === '{}', `${r.status} ${r.stdout}`);
});
passo('hook: repositório sem o fluxo só coleta, nunca nega', () => {
  const OUTRO = join(TMP, 'outro');
  mkdirSync(OUTRO);
  rodar('git', ['init', '-q', '-b', 'feature/ABC-77-tela'], { cwd: OUTRO });
  hook(['sessionStart'], { stdin: JSON.stringify({ sessionId: 'o1', cwd: OUTRO, source: 'new' }) });
  const r = hook(['preToolUse'], { stdin: JSON.stringify({ sessionId: 'o1', cwd: OUTRO, toolName: 'edit', toolArgs: { path: '.bchive/changes/x/revisao/a.md' } }) }).stdout;
  esperar(!/deny/.test(r), r);
  const ev = readdirSync(join(TMP, 'uso', 'eventos')).map((f) => readFileSync(join(TMP, 'uso', 'eventos', f), 'utf8')).join('');
  esperar(/"sid":"o1","repo":"outro","branch":"feature\/ABC-77-tela","ticket":"ABC-77"/.test(ev), 'evento sem repositório, branch e ticket da pasta do payload');
});

// ------------------------------------------------------------------ executores
passo('executores: descobertos com stack inferida; o plano aceita o nome completo; o do fluxo é ignorado', () => {
  escrever('.bchive/estado/executores-candidatos.json', JSON.stringify([
    { nome: 'java-plugin:spring-dev', descricao: 'Implements Spring Boot services in Java 21 with JUnit tests' },
    { nome: 'obs-plugin:dynatrace', descricao: 'Adds observability: OpenTelemetry tracing and logs' },
    { nome: `${NOME}:bchive-implementador`, descricao: 'do fluxo' },
  ]));
  const r = bchive('executores', 'registrar', '--de', '.bchive/estado/executores-candidatos.json').saida;
  esperar(/2 executor\(es\) descoberto/.test(r) && /java-plugin:spring-dev\s+\[java, testes\]/.test(r) && /obs-plugin:dynatrace\s+\[observabilidade\]/.test(r), r);
  const D = '.bchive/changes/INC-4473-usar-executor-java';
  escrever(`${D}/proposta.md`, '# Usar executor\n\nTicket: INC-4473\nBranch: main\nBase:   main\nRigor:  Lite\n\n## Intenção\nx\n\n## Escopo\nDentro: x. Fora: y.\n\n## Restrições\nnenhuma\n\n## Critérios de aceite\n1. MUST x. Dado a, quando b, então c.\n');
  escrever(`${D}/tarefas/01-bff.md`, '# 01. BFF\nDemonstra: x\nBloqueado por: nenhum\nToca: bff/\nExecutor: java-plugin:spring-dev\n\n## Ponteiros\n- proposta.md, critério 1\n\n- [ ] 1.1 Fazer x em `bff/src/main/java/br/exemplo/AcordoController.java`\n');
  escrever(`${D}/tarefas/02-verificacao.md`, '# 02. Verificação\nBloqueado por: todos\nEscopo: core\n\n- [ ] 2.1 verificar\n');
  let f = bchive('fatias', 'INC-4473-usar-executor-java').saida;
  esperar(/01 \(java-plugin:spring-dev\)/.test(f) && !/AVISO executor/.test(f), f);
  writeFileSync(join(REPO, D, 'tarefas', '01-bff.md'), readFileSync(join(REPO, D, 'tarefas', '01-bff.md'), 'utf8').replace('java-plugin:spring-dev', 'plugin-x:inexistente'));
  f = bchive('fatias', 'INC-4473-usar-executor-java').saida;
  esperar(/AVISO executor .*plugin-x:inexistente/.test(f), f);
  bchive('descartar', 'INC-4473-usar-executor-java', '--aplicar');
});

passo('lições: sinais da mudança arquivada (achado bloqueante, aceite) e revisão das vencidas', () => {
  const s = bchive('licoes', 'sinais', ID).saida;
  esperar(/achado bloqueante que virou trabalho/.test(s) && /revisão aceita apesar de reprovada/.test(s), s);
  const dir = join(REPO, 'conhecimento', 'licoes');
  const f = readdirSync(dir)[0];
  writeFileSync(join(dir, f), readFileSync(join(dir, f), 'utf8').replace(/revisar-em: \S+/, 'revisar-em: 2020-01-01'));
  esperar(/VENCIDA/.test(bchive('licoes', 'revisar').saida), 'lição vencida não apareceu');
  git('checkout', '--', `conhecimento/licoes/${f}`);
});

passo('legado: init avisa o que o mapa não lê e desliga o mapa antes de busca quando o legado é maioria', () => {
  const LEG = join(TMP, 'legado');
  mkdirSync(join(LEG, 'cobol'), { recursive: true });
  rodar('git', ['init', '-q', '-b', 'main'], { cwd: LEG });
  for (const n of ['CALC001', 'CALC002', 'CALC003']) writeFileSync(join(LEG, 'cobol', `${n}.cbl`), '       IDENTIFICATION DIVISION.\n       PROGRAM-ID. X.\n');
  writeFileSync(join(LEG, 'cobol', 'CONTRATO.cpy'), '       01 CONTRATO PIC X(10).\n');
  writeFileSync(join(LEG, 'job.jcl'), '//JOB1 JOB\n//STEP1 EXEC PGM=CALC001\n');
  rodar('git', ['add', '-A'], { cwd: LEG });
  rodar('git', ['-c', 'user.email=s@h', '-c', 'user.name=s', 'commit', '-qm', 'legado'], { cwd: LEG });
  node(join(PLUGIN, 'skills', 'init', 'scripts', 'init.mjs'), [], { ok: false, cwd: LEG });
  const j = JSON.parse(rodar(process.execPath, ['.bchive/bin/bchive.mjs', 'init', '--json'], { ok: false, cwd: LEG }).stdout);
  const it = j.itens.find((i) => i.id === 'mapa-cobertura');
  esperar(it && /5 arquivo\(s\) de legado/.test(it.txt), JSON.stringify(it));
  const cfgL = JSON.parse(readFileSync(join(LEG, '.bchive', 'bchive.json'), 'utf8'));
  esperar(cfgL.mapa?.primeiroAntesDeBusca === 'off', `mapa antes de busca continua ligado: ${JSON.stringify(cfgL.mapa)}`);
});

passo('executores conferir: agente de plugin travado ou sem edição é GRAVE; corrigido, pronto', () => {
  let r = node('.bchive/bin/bchive.mjs', ['executores', 'conferir', 'java-plugin:spring-dev'], { ok: false });
  esperar(r.status === 1 && /NÃO ACHADO/.test(r.saida), r.saida);
  const dir = join(CASA, '.copilot', 'installed-plugins', 'bradesco-marketplace', 'java-plugin', 'com.github.copilot', 'agents');
  mkdirSync(dir, { recursive: true });
  const pAg = join(dir, 'spring-dev.agent.md');
  writeFileSync(pAg, '---\nname: spring-dev\ndescription: "Implements Spring Boot services in Java 21"\ntools: ["read", "search"]\ndisable-model-invocation: true\nhandoffs: []\n---\n# Java\n');
  r = node('.bchive/bin/bchive.mjs', ['executores', 'conferir', 'java-plugin:spring-dev'], { ok: false });
  esperar(r.status === 1 && /disable-model-invocation: true/.test(r.saida) && /sem edição/.test(r.saida) && /"handoffs"/.test(r.saida), r.saida);
  writeFileSync(pAg, '---\nname: spring-dev\ndescription: "Implements Spring Boot services in Java 21"\ntools:\n- read\n- search\n- edit\n- execute\n---\n# Java\n\n## When called with a slice file\nChange only the paths in `Toca:`.\n');
  r = node('.bchive/bin/bchive.mjs', ['executores', 'conferir', 'java-plugin:spring-dev']);
  esperar(/java-plugin:spring-dev \(.*spring-dev\.agent\.md\): pronto/.test(r.saida), r.saida);
  writeFileSync(join(REPO, '.bchive', 'estado', 'cand-cobol.json'), JSON.stringify([{ nome: 'mf-plugin:cobol-dev', descricao: 'Implements COBOL batch programs, JCL and DB2 copybooks on z/OS' }]));
  r = node('.bchive/bin/bchive.mjs', ['executores', 'registrar', '--de', '.bchive/estado/cand-cobol.json'], { ok: false }).saida;
  esperar(/mf-plugin:cobol-dev\s+\[[^\]]*mainframe/.test(r), r);
});

passo('auditar: custo fixo, termo vago, conflito com o fluxo, applyTo "**", hook relativo, agente do fluxo duplicado; init só informa', () => {
  escrever('AGENTS.md', '# Time\n\nSempre que possível use signals.\nFaça commit ao terminar cada tarefa.\nOs testes ficam ao lado do componente e usam Jest com Testing Library.\n');
  escrever('.github/instructions/tudo.instructions.md', '---\napplyTo: "**"\n---\nOs testes ficam ao lado do componente e usam Jest com Testing Library.\nUse Karma nos testes.\n');
  escrever('.github/hooks/meu.json', JSON.stringify({ version: 1, hooks: { preToolUse: [{ type: 'command', bash: 'node scripts/guarda.mjs' }] } }));
  escrever('.github/agents/bchive-plan.agent.md', '---\nname: bchive-plan\n---\nantigo\n');
  const arv = node('.bchive/bin/bchive.mjs', ['arvore'], { ok: false }).saida;
  esperar(!/AGENTS|\.github/.test(arv), `personalização em .github contou como alteração: ${arv}`);
  const it = item(initJson(), 'personalizacao');
  esperar(it?.nivel === 'ok' && /não bloqueiam/.test(it.txt), JSON.stringify(it));
  const r = bchive('squad-audit', '--usuario').saida;
  esperar(/custo fixo estimado por pedido: ≈\d+ tokens/.test(r), r);
  esperar(/AGENTS\.md:\d+ \[vago\] "Sempre que possível"/.test(r) && /AGENTS\.md:\d+ \[conflito-fluxo\]/.test(r), r);
  esperar(/GRAVE \.github\/hooks\/meu\.json \[hook\] preToolUse \(bash\): caminho relativo/.test(r) && /GRAVE \.github\/agents\/bchive-plan\.agent\.md \[duplicado\]/.test(r), r);
  const pasta = join(REPO, '.bchive', 'estado', 'auditoria', new Date().toISOString().slice(0, 10));
  const j = JSON.parse(readFileSync(join(pasta, 'achados.json'), 'utf8'));
  esperar(j.achados.some((a) => a.regra === 'repetido') && j.achados.some((a) => a.regra === 'instrucao' && /carrega em todo pedido/.test(a.txt)) && j.topicos['teste (runner)'], JSON.stringify(j.achados.map((a) => a.regra)));
  esperar(j.inventario.some((x) => x.escopo === 'plugin' && /spring-dev/.test(x.rel)), 'plugin instalado fora do inventário');
  const tr = readFileSync(join(pasta, 'trechos.md'), 'utf8');
  esperar(/Sempre que possível use signals/.test(tr) && /### teste \(runner\)/.test(tr), tr.slice(0, 800));
  rmSync(join(REPO, 'AGENTS.md'));
  rmSync(join(REPO, '.github'), { recursive: true, force: true });
});

// ------------------------------------------------------------------ uso
passo('uso: turnos (sem dobrar com o hook do agente), fluxo × solto, tempo, tokens pelo trace, exportação sem dinheiro', () => {
  const USO = join(TMP, 'uso-relatorio');
  const env = { ...ENVT, BCHIVE_USO: USO };
  const agora = Date.now();
  const tp = (t) => `00-${t}-00f067aa0ba902b7-01`;
  const T1 = '4bf92f3577b34da6a3ce929d0e0e4736';
  const ev = (nome, corpo, agente) => hook([nome, ...(agente ? ['--agente', agente] : [])], { env, stdin: JSON.stringify({ cwd: REPO, ...corpo }) });
  // sessão do fluxo: comando do plugin, turno do agente (global + frontmatter), skill, subagente e o turno dele
  ev('sessionStart', { sessionId: 'u1', source: 'new', initialPrompt: `/${NOME}:plan .bchive/briefings/x/briefing.md segredo`, traceparent: tp(T1) });
  ev('userPromptSubmitted', { sessionId: 'u1', prompt: `/${NOME}:plan segredo`, traceparent: tp(T1) });
  ev('userPromptSubmitted', { sessionId: 'u1', prompt: `/${NOME}:plan segredo`, traceparent: tp(T1) }, 'bchive-plan');
  ev('preToolUse', { sessionId: 'u1', toolName: 'skill', toolArgs: { name: `${NOME}:plan` }, traceparent: tp(T1) });
  ev('subagentStart', { sessionId: 'u1', agentName: `${NOME}:bchive-gf`, agentId: 'g1', traceparent: tp(T1) });
  ev('userPromptSubmitted', { sessionId: 'u1', agentId: 'g1', parentAgentId: 'main', agentType: 'custom', prompt: 'Review package: x', traceparent: tp(T1) });
  ev('preToolUse', { sessionId: 'u1', toolName: 'task', toolArgs: { agent_type: 'java-plugin:spring-dev', prompt: 'segredo' }, traceparent: tp(T1) });
  ev('sessionEnd', { sessionId: 'u1', reason: 'complete' });
  // chat solto
  ev('sessionStart', { sessionId: 'u2', source: 'new', initialPrompt: 'explique este erro segredo' });
  ev('userPromptSubmitted', { sessionId: 'u2', prompt: 'explique este erro segredo' });
  ev('sessionEnd', { sessionId: 'u2', reason: 'complete' });
  // telemetria do Agent Host: duas chamadas do trace da sessão do fluxo e um invoke_agent (total, ignorado)
  const span = (id, inT, outT, op = 'chat') => ({ traceId: T1, name: `${op} claude-sonnet-5`, startTimeUnixNano: String((agora - 1000) * 1e6), attributes: { 'gen_ai.operation.name': op, 'gen_ai.response.model': 'claude-sonnet-5', 'gen_ai.response.id': id, 'gen_ai.usage.input_tokens': inT, 'gen_ai.usage.output_tokens': outT } });
  writeFileSync(ENV.BCHIVE_OTEL_AGENT_HOST, [span('r1', 12000, 300), span('r2', 8000, 200), span('r3', 99999, 9999, 'invoke_agent')].map((x) => JSON.stringify(x)).join('\n') + '\n');
  const j = JSON.parse(node('.bchive/bin/uso.mjs', ['relatorio', '--json'], { env }).stdout);
  const t = j.totais;
  esperar(t.sessoes === 2 && t.sessoesFluxo === 1 && t.sessoesSoltas === 1, JSON.stringify(t));
  esperar(t.turnosPrincipal === 2 && t.turnosSubagente === 1 && t.subagentesIniciados === 1, `turnos: ${JSON.stringify(t)}`);
  esperar(t.tokensEntrada === 20000 && t.tokensSaida === 500, `tokens: ${JSON.stringify(t)}`);
  esperar(j.agentesChamados['java-plugin:spring-dev'] === 1 && j.comandos[`/${NOME}:plan`], JSON.stringify({ a: j.agentesChamados, c: j.comandos }));
  node('.bchive/bin/uso.mjs', ['exportar'], { env });
  const pasta = join(USO, 'exportar');
  const doc = readFileSync(join(pasta, readdirSync(pasta)[0]), 'utf8');
  esperar(/"formato": "bchive-uso\/1"/.test(doc) && !/custo|cr[eé]dito|pre[cç]o|price|cost|aiu|"R\$|segredo/i.test(doc), 'exportação com dinheiro ou conteúdo de prompt');
  const eventos = readdirSync(join(USO, 'eventos')).map((f) => readFileSync(join(USO, 'eventos', f), 'utf8')).join('');
  esperar(!/segredo|Review package|briefing\.md/.test(eventos), 'evento com conteúdo de prompt ou argumento');
});
passo('uso: selos encadeados acusam evento alterado', () => {
  const USO = join(TMP, 'uso-selos');
  const env = { ...ENVT, BCHIVE_USO: USO };
  const ontem = new Date(Date.now() - 864e5).toISOString();
  const anteontem = new Date(Date.now() - 2 * 864e5).toISOString();
  const linhas = [anteontem, ontem].map((t, i) => JSON.stringify({ t, ev: 'userPromptSubmitted', sid: `x${i}`, repo: 'r', branch: 'main', ticket: null, turno: 'principal' }));
  const p = join(USO, 'eventos', `${ontem.slice(0, 7)}.jsonl`);
  const p0 = join(USO, 'eventos', `${anteontem.slice(0, 7)}.jsonl`);
  mkdirSync(dirname(p), { recursive: true });
  if (p === p0) writeFileSync(p, `${linhas.join('\n')}\n`);
  else { writeFileSync(p0, `${linhas[0]}\n`); writeFileSync(p, `${linhas[1]}\n`); }
  esperar(/2 dia\(s\) selado/.test(node('.bchive/bin/uso.mjs', ['selar'], { env }).saida), 'não selou os dois dias');
  esperar(/cadeia íntegra/.test(node('.bchive/bin/uso.mjs', ['verificar-selos'], { env }).saida), 'cadeia deveria estar íntegra');
  writeFileSync(p, readFileSync(p, 'utf8').replace('"turno":"principal"', '"turno":"subagente"'));
  const r = node('.bchive/bin/uso.mjs', ['verificar-selos'], { env, ok: false });
  esperar(r.status === 1 && /alterados depois do selo/.test(r.saida), r.saida);
});

passo('briefing: insumos pendentes ou só link do Figma impedem o plano', () => {
  const B = '.bchive/briefings/INC-4472-confirmacao-duplicada';
  const tabela = (telas, contrato) => `| Insumo | Situação | Onde | Observação |\n| --- | --- | --- | --- |\n| Ticket e critérios do PO | ok | Jira INC-4472 | |\n| Telas (Figma) e análise | ${telas} |\n| Contrato de API por camada | ${contrato} |\n| Regras de negócio e limites | ok | seção O que se espera | |\n| Estados de tela e erros | ok | \`figma.md\` | |\n| Configuração e parametrização | não se aplica | | sem parâmetro novo |\n| Exemplos concretos | ok | seção O que se espera | contrato 123 |\n| Dependências de outros times | não se aplica | | BFF já pronto |\n`;
  const briefing = (t) => `# Briefing - confirmação duplicada\n\n## Problema\nO gerente confirma duas vezes.\n\n## O que se espera\nUm acordo por contrato. Exemplo: contrato 123.\n\n## Restrições\nNão mudar o BFF.\n\n## Fora do escopo\nRelatórios.\n\n## Insumos\n\n${t}\n## Prazo e ticket\nINC-4472\n`;
  escrever(`${B}/figma.md`, '# Análise\n');
  escrever(`${B}/briefing.md`, briefing(tabela('ok | https://www.figma.com/design/x?node-id=1 | ', 'pendente | | dev manda o caminho')));
  let r = node('.bchive/bin/bchive.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 1 && /só link do Figma/.test(r.saida) && /insumo pendente: Contrato de API/.test(r.saida), r.saida);
  escrever(`${B}/briefing.md`, briefing(tabela('ok | https://www.figma.com/design/x?node-id=1, `figma.md` | ', 'ok | MFE: `src/app/core/api/acordo-api.ts`; BFF: `bff/src/main/java/br/exemplo/AcordoController.java` | ')));
  r = node('.bchive/bin/bchive.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 0, r.saida);
  escrever(`${B}/briefing.md`, '# Briefing - antigo\n\n## Problema\np\n\n## O que se espera\ne\n\n## Restrições\nr\n\n## Fora do escopo\nf\n\n## Prazo e ticket\nINC-4472\n');
  r = node('.bchive/bin/bchive.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 1 && /sem a seção Insumos/.test(r.saida), r.saida);
});

passo('rigor Full sem gatilho é recusado; descartar mostra, só o dev apaga, e limpa o estado', () => {
  const D = '.bchive/changes/INC-4472-testar-rigor';
  escrever(`${D}/briefing.md`, readFileSync(join(REPO, '.bchive/briefings/INC-4472-confirmacao-duplicada/briefing.md'), 'utf8'));
  escrever(`${D}/proposta.md`, '# Testar rigor\n\nTicket: INC-4472\nBranch: main\nBase:   main\nRigor:  Full\n\n## Intenção\nx\n\n## Escopo\nDentro: x. Fora: y.\n\n## Restrições\nnenhuma\n\n## Critérios de aceite\nnenhum\n');
  escrever(`${D}/design.md`, '# Design\n');
  let r = node('.bchive/bin/bchive.mjs', ['validar', 'INC-4472-testar-rigor'], { ok: false });
  esperar(r.status === 1 && /Rigor Full sem gatilho/.test(r.saida), r.saida);
  writeFileSync(join(REPO, '.bchive/estado/pacotes.jsonl'), `${readFileSync(join(REPO, '.bchive/estado/pacotes.jsonl'), 'utf8')}${JSON.stringify({ change: 'INC-4472-testar-rigor', alvo: 'design' })}\n`);
  r = bchive('descartar', 'INC-4472-testar-rigor', '--com-briefing');
  esperar(/prévia/.test(r.saida) && /1 pacote/.test(r.saida) && /INC-4472-confirmacao-duplicada/.test(r.saida) && existsSync(join(REPO, D)), r.saida);
  const neg = hook(['preToolUse'], { stdin: JSON.stringify({ sessionId: 'd1', cwd: REPO, toolName: 'bash', toolArgs: { command: 'node .bchive/bin/bchive.mjs descartar INC-4472-testar-rigor --aplicar' } }) }).stdout;
  esperar(/deny/.test(neg), `hook deixou o agente descartar: ${neg}`);
  bchive('descartar', 'INC-4472-testar-rigor', '--com-briefing', '--aplicar');
  esperar(!existsSync(join(REPO, D)) && !existsSync(join(REPO, '.bchive/briefings/INC-4472-confirmacao-duplicada')), 'descartar não apagou a mudança e o briefing');
  esperar(!/INC-4472-testar-rigor/.test(readFileSync(join(REPO, '.bchive/estado/pacotes.jsonl'), 'utf8')), 'estado da mudança ficou em pacotes.jsonl');
  esperar(/INC-4472-evitar-acordo-duplicado|"change"/.test(readFileSync(join(REPO, '.bchive/estado/pacotes.jsonl'), 'utf8')), 'descartar apagou estado de outra mudança');
});

// ------------------------------------------------- repositórios fora do padrão (P3)
function repoExtra(nome, arquivos) {
  const R = join(TMP, nome);
  for (const [p, t] of Object.entries(arquivos)) { mkdirSync(dirname(join(R, p)), { recursive: true }); writeFileSync(join(R, p), t); }
  const g = (...a) => rodar('git', ['-c', 'user.email=smoke@bchive', '-c', 'user.name=smoke', ...a], { cwd: R });
  g('init', '-q', '-b', 'main'); g('add', '-A'); g('commit', '-qm', 'base');
  return R;
}
const initEm = (R) => node(join(PLUGIN, 'skills', 'init', 'scripts', 'init.mjs'), [], { cwd: R, ok: false });

passo('fora do padrão: sem package.json (Java + front em subpasta) e Node sem src/ recebem proposta sem verificação, sem erro', () => {
  const java = {};
  for (let i = 0; i < 5; i++) java[`modulo/src/main/java/br/C${i}.java`] = `package br;\npublic class C${i} { }\n`;
  const R = repoExtra('monolito', { 'pom.xml': '<project/>', 'frontend/package.json': '{"name":"front","devDependencies":{"jest":"29"}}', 'frontend/src/app/a.ts': 'export const a = 1;\n', ...java });
  let r = initEm(R);
  esperar(r.status === 0, r.saida);
  r = node('.bchive/bin/configurar.mjs', ['verificacao'], { cwd: R, ok: false });
  esperar(r.status === 0 && /sem package\.json na raiz/.test(r.saida) && /Sem verificação automática/.test(r.saida) && /pom\.xml/.test(r.saida) && /projeto Node em frontend\//.test(r.saida) && /modulo\s+modulo\/\*\*/.test(r.saida), r.saida);
  node('.bchive/bin/configurar.mjs', ['verificacao', '--gravar'], { cwd: R });
  r = node('.bchive/bin/bchive.mjs', ['init'], { cwd: R, ok: false });
  esperar(!/verificacao\s+.*molde de MFE/.test(r.saida), `init ainda aponta o molde depois do --gravar:\n${r.saida}`);
  const N = repoExtra('node-sem-src', { 'package.json': '{"name":"nu"}', 'lib/m.js': 'module.exports = 1;\n' });
  esperar(initEm(N).status === 0, 'init falhou no Node sem src/');
  r = node('.bchive/bin/configurar.mjs', ['verificacao'], { cwd: N, ok: false });
  esperar(r.status === 0 && /lib\s+lib\/\*\*/.test(r.saida) && /Sem verificação automática/.test(r.saida), r.saida);
});

passo('fora do padrão: pastas de log fora do Git vão para pastasLocais; árvore limpa, mapa e configurar sem log; laço de link não derruba; falha mostra o motivo', () => {
  const R = repoExtra('logs', { 'package.json': '{"name":"logs","devDependencies":{"typescript":"5"}}', 'tsconfig.json': '{}', 'src/app/core/a.ts': 'export const a = 1;\n' });
  for (let p = 1; p <= 3; p++) for (let f = 0; f < 60; f++) { mkdirSync(join(R, `log-fico-${p}`, 'exec'), { recursive: true }); writeFileSync(join(R, `log-fico-${p}`, 'exec', `r${f}.json`), '{"req":1}\n'); }
  writeFileSync(join(R, 'log-fico-1', 'exec', 'mock.js'), 'module.exports = {};\n');
  writeFileSync(join(R, 'src/app/core/b.ts'), 'export const b = 2;\n');
  try { symlinkSync('..', join(R, 'log-fico-2', 'volta'), 'junction'); } catch { /* sem link nesta máquina */ }
  let r = initEm(R);
  esperar(r.status === 0 && /corrigido\s+pastas-locais\s+3 pasta/.test(r.saida), r.saida);
  const cfg = JSON.parse(readFileSync(join(R, '.bchive', 'bchive.json'), 'utf8'));
  esperar(['log-fico-1', 'log-fico-2', 'log-fico-3'].every((n) => cfg.pastasLocais.includes(n)), `pastasLocais: ${cfg.pastasLocais}`);
  r = node('.bchive/bin/bchive.mjs', ['arvore'], { cwd: R, ok: false });
  esperar(/NÃO COMMITADO: src\/app\/core\/b\.ts$/m.test(r.saida.trim()) && !/log-fico/.test(r.saida), `árvore: ${r.saida}`);
  const g = JSON.parse(readFileSync(join(R, '.bchive', 'mapa', 'graph.json'), 'utf8'));
  esperar(!g.nodes.some((n) => /log-fico/.test(n.source_file || '')) && g.nodes.some((n) => /core\/b\.ts/.test(n.source_file || '')), 'mapa leu pasta de log ou perdeu o arquivo novo do produto');
  r = node('.bchive/bin/configurar.mjs', ['verificacao'], { cwd: R, ok: false });
  esperar(r.status === 0 && !/log-fico/.test(r.saida) && /core\s+src\/app\/core/.test(r.saida), r.saida);
  r = node('.bchive/bin/bchivemap.mjs', ['query', 'a'], { cwd: R, ok: false });
  esperar(r.status === 0, `consulta ao mapa: ${r.saida}`);
  // URL file:// e não caminho: no Windows, import('C:/...') falha (ERR_UNSUPPORTED_ESM_URL_SCHEME).
  const rm = spawnSync(process.execPath, ['--input-type=module', '-e', `import('${pathToFileURL(join(R, '.bchive', 'bin', 'lib', 'comum.mjs')).href}').then((m) => console.log(m.motivoFalha({ status: 1, stderr: "node:fs:1\\n  throw err; // EPERM: x\\n\\nError: EPERM: operation not permitted, scandir 'log'\\n    at readdirSync\\nNode.js v22" }) + '|' + m.motivoFalha({ status: null, signal: 'SIGTERM' }, { minutos: 4 })))`], { encoding: 'utf8' });
  const motivo = rm.stdout || '';
  esperar(/^Error: EPERM: operation not permitted, scandir 'log'\|interrompido depois de 4 min/.test(motivo), `motivoFalha: ${motivo}${rm.stderr || ''}`);
});

passo('Node fora de 22/24: init e configurar travam abaixo de 22 com o documento do Confluence; ímpar só avisa', () => {
  const R = repoExtra('node-versao', { 'package.json': '{"name":"v"}', 'src/app/a/a.js': 'module.exports = 1;\n' });
  const comNode = (v) => ({ ...ENV, BCHIVE_NODE_SIMULAR: v });
  let r = rodar(process.execPath, [join(PLUGIN, 'skills', 'init', 'scripts', 'init.mjs')], { cwd: R, ok: false, env: comNode('20.11.1') });
  esperar(r.status === 2 && /Node 20\.11\.1 encontrado/.test(r.saida) && /LTS 22 ou 24/.test(r.saida) && /Confluence do banco/.test(r.saida) && !existsSync(join(R, '.bchive')), `Node 20: ${r.saida}`);
  r = rodar(process.execPath, [join(PLUGIN, 'skills', 'init', 'scripts', 'init.mjs')], { cwd: R, ok: false, env: comNode('23.1.0') });
  esperar(r.status === 0 && /aviso\s+node\s+Node 23\.1\.0 não é uma LTS validada/.test(r.saida) && /Confluence/.test(r.saida), `Node 23: ${r.saida}`);
  r = rodar(process.execPath, ['.bchive/bin/configurar.mjs', 'verificacao'], { cwd: R, ok: false, env: comNode('18.20.0') });
  esperar(r.status === 2 && /Confluence do banco/.test(r.saida), `configurar com Node 18: ${r.saida}`);
  r = rodar(process.execPath, ['.bchive/bin/bchive.mjs', 'arvore'], { cwd: R, ok: false, env: comNode('18.20.0') });
  esperar(/AVISO Node 18\.20\.0 encontrado/.test(r.saida), `CLI com Node 18: ${r.saida}`);
  esperar(!/Node|Confluence/.test(node('.bchive/bin/bchive.mjs', ['arvore'], { cwd: R, ok: false }).saida), 'Node suportado não deve avisar');
});

console.log(`\n${passos - falhas}/${passos} passos ok${falhas ? `, ${falhas} falha(s)` : ''}. Pasta: ${TMP}`);
if (!process.argv.includes('--manter') && !falhas) rmSync(TMP, { recursive: true, force: true });
process.exit(falhas ? 1 : 0);
