#!/usr/bin/env node
// b.IA Credit Hive - auditoria da personalização do Copilot do dev: instruções, AGENTS.md, agentes, skills,
// prompts e hooks (do repositório, do usuário e de plugins instalados) e a configuração do fluxo.
// Só leitura: nunca edita arquivo do dev. Sem dependência, Node LTS 22 ou 24.
//
//   node .bchive/bin/auditar.mjs [--usuario] [--json]
//
// O script faz a parte mecânica (inventário, custo estimado em tokens, termos vagos, duplicatas, frontmatter,
// hooks, conflitos prováveis com o fluxo) e separa os trechos que pedem julgamento em trechos.md. O agente
// lê só isso e escreve o relatório. Saída em .bchive/estado/auditoria/<data>/ (fora do Git).

import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync } from 'node:fs';
import { join, basename, dirname } from 'node:path';
import { HW, ESTADO, sair, barra, lerJson, gravarJson, globParaRegex } from './lib/comum.mjs';
import { inventario, estimarTokens, linhasNumeradas, conferirExecutor, nomeChamavel } from './lib/personalizacao.mjs';

const RAIZ = process.cwd();
const args = process.argv.slice(2);
const usuario = args.includes('--usuario');
if (!existsSync(join(RAIZ, HW))) sair(2, `${HW}/ não existe aqui: rode da raiz do repositório preparado pelo init.`);

const itens = inventario(RAIZ, { usuario });
const achados = [];
const achar = (item, nivel, regra, txt, linha = null) => achados.push({ arquivo: item ? item.rel : null, nivel, regra, txt, linha });

// Arquivos do repositório, para saber se um applyTo casa com alguma coisa.
const rastreados = (spawnSync('git', ['ls-files'], { cwd: RAIZ, encoding: 'utf8', maxBuffer: 1 << 26 }).stdout || '').split('\n').filter(Boolean);

const VAGOS = /(?<![\p{L}])(quando poss[ií]vel|sempre que poss[ií]vel|se necess[aá]rio|quando necess[aá]rio|quando fizer sentido|de forma adequada|adequad[oa]s?|apropriad[oa]s?|boas pr[aá]ticas|best practices|c[oó]digo limpo|clean code|bem estruturad[oa]|robust[oa]s?|escal[aá]vel|perform[aá]tic[oa]|corretamente|properly|as appropriate|if needed|when possible|try to|tente|procure|considere|consider|evite|e afins|etc\.?)(?![\p{L}])/giu;
const GIT_ESCRITA = /\b(fa[cç]a (o )?commit|commite|git (commit|push)|crie (a|uma) branch|abra (a|uma) (pr|pull request)|create (a )?(branch|pull request)|commit (the|your) changes|push (the|your) changes)\b/i;
const IDIOMA = /\b(responda|escreva|answer|respond|reply|write)\b[^.\n]{0,40}\b(em ingl[eê]s|in english|em espanhol|in spanish)\b/i;
const SEGREDO = /\b(senha|password|passwd|token|api[_-]?key|secret|client[_-]?secret)\b\s*[:=]\s*["']?[^\s"']{6,}/i;
const TOPICOS = {
  'teste (runner)': /\b(jest|karma|jasmine|vitest|mocha)\b/i,
  'teste e2e': /\b(cypress|playwright|protractor)\b/i,
  'estado (Angular)': /\b(ngrx|signal ?store|signals?|akita|ngxs)\b/i,
  'assíncrono': /\b(rxjs|observables?|promises?|async\/await)\b/i,
  'componentes Angular': /\b(standalone|ngmodule|onpush|zoneless|zone\.js)\b/i,
  'estilo': /\b(tailwind|scss|sass|liquid|css modules?)\b/i,
  'Java': /\b(junit|mockito|lombok|spring|records?|java ?\d+|liberty)\b/i,
  'React': /\b(react|redux|zustand|next\.?js)\b/i,
  'Git e PR': /\b(commit|branch|pull request|\bpr\b|push)\b/i,
  'idioma': /\b(portugu[eê]s|ingl[eê]s|english|portuguese)\b/i,
};
const agentesDoFluxo = /^(bchive|bchive)(-|$)|(^|:)bchive(-[a-z]+)?$/;

const sempreCarregado = (it) => {
  if (it.tipo === 'instrucoes-gerais' || (it.tipo === 'agents-md' && dirname(it.rel) === '.')) return true;
  if (it.tipo === 'instrucao') return [].concat(it.fm?.applyTo || []).join(',').split(',').some((g) => g.trim() === '**' || g.trim() === '**/*');
  return false;
};
const carga = (it) => {
  if (it.escopo === 'plugin') return 'quando o agente ou a skill é usado';
  if (sempreCarregado(it)) return 'todo pedido';
  if (it.tipo === 'agents-md') return 'pedidos sobre arquivos desta pasta (AGENTS.md aninhado)';
  if (it.tipo === 'instrucao') return it.fm?.applyTo ? `arquivos que casam com ${[].concat(it.fm.applyTo).join(',')}` : 'só se o modelo decidir ler (sem applyTo)';
  if (it.tipo === 'agente') return 'quando o agente é selecionado ou chamado';
  if (it.tipo === 'skill' || it.tipo === 'prompt') return 'quando chamado (a description fica sempre no contexto)';
  if (it.tipo === 'hooks') return 'eventos do chat';
  return '?';
};

// ------------------------------------------------------------------ por arquivo
const nomes = new Map();
for (const it of itens) {
  const fm = it.fm || {};
  const tok = estimarTokens(it.corpo);
  it.tokens = tok;
  if (it.tipo !== 'hooks') {
    // Tamanho
    const limite = it.tipo === 'skill' ? 5000 : it.tipo === 'agente' ? 2500 : 1500;
    if (sempreCarregado(it) && tok > 3000) achar(it, 'grave', 'tamanho', `≈${tok} tokens carregados em todo pedido, em todo chat (inclusive nos agentes do fluxo e no revisor). Corte para o que muda o resultado.`);
    else if (tok > limite) achar(it, 'aviso', 'tamanho', `≈${tok} tokens (referência para ${it.tipo}: até ≈${limite}).`);
    // Linha a linha
    let vagos = 0;
    for (const { n, l } of linhasNumeradas(it.corpo, it.linhaCorpo)) {
      if (/^\s*```/.test(l)) continue;
      const termos = [...l.matchAll(VAGOS)].map((m) => m[1]);
      if (termos.length && vagos < 15) { vagos++; achar(it, 'aviso', 'vago', `${termos.map((t) => `"${t}"`).join(', ')}: o modelo decide sozinho o que isso quer dizer, e cada chat decide diferente. Troque por um critério verificável.`, n); }
      if (GIT_ESCRITA.test(l)) achar(it, 'aviso', 'conflito-fluxo', 'manda o agente escrever no Git (commit, push, branch ou PR). Nos agentes do fluxo isso não vale (o dev commita); fora dele, confira se é o que o time quer.', n);
      if (IDIOMA.test(l)) achar(it, 'aviso', 'conflito-fluxo', 'fixa o idioma das respostas. O fluxo responde e escreve artefatos em português; o pacote e o contrato vencem, mas a instrução gasta tokens brigando com eles.', n);
      if (SEGREDO.test(l)) achar(it, 'grave', 'segredo', 'parece credencial escrita no arquivo. Tire daqui e troque a credencial.', n);
    }
  }
  if (it.tipo === 'instrucao') {
    const apply = [].concat(fm.applyTo || []).join(',');
    if (!apply) achar(it, 'aviso', 'instrucao', 'sem "applyTo": não é aplicada pelo caminho do arquivo; depende do modelo decidir ler.');
    else if (!sempreCarregado(it) && rastreados.length) {
      const globs = apply.split(',').map((g) => g.trim()).filter(Boolean);
      if (!rastreados.some((a) => globs.some((g) => globParaRegex(g).test(a)))) achar(it, 'aviso', 'instrucao', `applyTo "${apply}" não casa com nenhum arquivo do repositório: instrução morta ou glob errado.`);
    }
    if (sempreCarregado(it)) achar(it, 'aviso', 'instrucao', `applyTo "${apply}" carrega em todo pedido. Se a regra é de uma pasta ou tipo de arquivo, restrinja o glob.`);
    if (!fm.description) achar(it, 'aviso', 'instrucao', 'sem "description": no harness Copilot o modelo usa a description para decidir ler a instrução sob demanda.');
  }
  if (it.tipo === 'agente') {
    const nome = nomeChamavel(it);
    if (!nomes.has(nome)) nomes.set(nome, []);
    nomes.get(nome).push(it.rel);
    if (!fm.description) achar(it, 'aviso', 'agente', 'sem "description": o seletor e quem delega não sabem para que serve.');
    if (!fm.tools) achar(it, 'aviso', 'agente', 'sem "tools": recebe todas as ferramentas. Declare só as que o papel precisa.');
    for (const k of ['agents', 'handoffs', 'argument-hint']) if (fm[k] !== undefined) achar(it, 'aviso', 'agente', `chave "${k}": o harness Copilot não aceita no frontmatter de agente.`);
    if (/^true$/i.test(String(fm['disable-model-invocation'] ?? '')) && /^false$/i.test(String(fm['user-invocable'] ?? ''))) achar(it, 'grave', 'agente', '"disable-model-invocation: true" e "user-invocable: false": ninguém consegue usar este agente.');
    if (it.escopo !== 'plugin' && agentesDoFluxo.test(basename(it.caminho).replace(/\.agent\.md$/, ''))) achar(it, 'grave', 'duplicado', 'agente com nome do fluxo fora do plugin (sobra da instalação pelo zip): aparece em dobro no seletor. Apague.');
    if (it.escopo === 'perfil-vscode') achar(it, 'aviso', 'agente', 'agente na pasta do perfil do VS Code: no harness Copilot não aparece. Mova para ~/.copilot/agents/.');
  }
  if (it.tipo === 'skill') {
    const pasta = basename(dirname(it.caminho));
    if (fm.name && fm.name !== pasta) achar(it, 'aviso', 'skill', `name "${fm.name}" diferente da pasta "${pasta}".`);
    if (!/^[a-z0-9-]{1,64}$/.test(fm.name || pasta)) achar(it, 'aviso', 'skill', 'nome fora do padrão (minúsculas, números e hífen, até 64).');
    if (!fm.description) achar(it, 'grave', 'skill', 'sem "description": a skill não é descoberta.');
    else if (String(fm.description).length > 1024) achar(it, 'aviso', 'skill', 'description acima de 1024 caracteres: fica no contexto de todo chat.');
    if (it.corpo.split('\n').length > 500) achar(it, 'aviso', 'skill', 'SKILL.md com mais de 500 linhas: mova detalhe para references/.');
  }
  if (it.tipo === 'prompt' && !fm.description) achar(it, 'aviso', 'prompt', 'sem "description".');
  if (it.tipo === 'hooks') {
    let j;
    try { j = JSON.parse(it.texto); } catch { achar(it, 'grave', 'hook', 'JSON inválido: nenhum hook deste arquivo roda.'); continue; }
    for (const [ev, lista] of Object.entries(j.hooks || {})) {
      for (const h of [].concat(lista || [])) {
        const cmds = ['command', 'bash', 'powershell'].map((k) => [k, h[k]]).filter(([, v]) => typeof v === 'string');
        if (!h.powershell) achar(it, 'aviso', 'hook', `${ev}: sem a variante "powershell". No Windows o harness Copilot roda essa (a chave "command" não rodou na sondagem).`);
        for (const [k, c] of cmds) {
          if (!/exit 0|\|\|\s*true/.test(c)) achar(it, 'aviso', 'hook', `${ev} (${k}): sem "exit 0" ou "|| true". Erro no script em preToolUse nega a ferramenta do chat.`);
          const script = (c.match(/\b(?:node|python3?|bash|sh|pwsh|powershell)(?:\.exe)?\s+["']?([^\s"']+)/) || [])[1];
          if (script && !/^(\$|%|\/|[A-Za-z]:|~)/.test(script)) achar(it, 'grave', 'hook', `${ev} (${k}): caminho relativo "${script}". O processo do hook não roda na raiz do repositório: use caminho absoluto, variável (PLUGIN_ROOT) ou leia o "cwd" do payload.`);
        }
        if (!h.timeoutSec) achar(it, 'aviso', 'hook', `${ev}: sem "timeoutSec".`);
        else if (Number(h.timeoutSec) > 30) achar(it, 'aviso', 'hook', `${ev}: timeout de ${h.timeoutSec}s segura o chat.`);
      }
    }
  }
}
for (const [nome, onde] of nomes) if (onde.length > 1) achados.push({ arquivo: onde.join(', '), nivel: 'aviso', regra: 'duplicado', txt: `dois agentes chamados "${nome}": o seletor e a delegação ficam ambíguos.`, linha: null });

// ------------------------------------------------------------------ entre arquivos
const textuais = itens.filter((it) => it.tipo !== 'hooks' && it.escopo !== 'plugin');
const porLinha = new Map();
for (const it of textuais) {
  for (const { n, l } of linhasNumeradas(it.corpo, it.linhaCorpo)) {
    const k = l.toLowerCase().replace(/[`*_>#\-\d.)]/g, ' ').replace(/\s+/g, ' ').trim();
    if (k.length < 40) continue;
    if (!porLinha.has(k)) porLinha.set(k, []);
    porLinha.get(k).push(`${it.rel}:${n}`);
  }
}
const duplicadas = [...porLinha.values()].filter((v) => new Set(v.map((x) => x.split(':')[0])).size > 1);
for (const d of duplicadas.slice(0, 30)) achados.push({ arquivo: d.join(' | '), nivel: 'aviso', regra: 'repetido', txt: 'a mesma regra em mais de um arquivo: paga tokens duas vezes e diverge na primeira edição.', linha: null });
const topicos = {};
for (const [t, re] of Object.entries(TOPICOS)) {
  const linhas = [];
  for (const it of textuais) for (const { n, l } of linhasNumeradas(it.corpo, it.linhaCorpo)) if (re.test(l) && l.trim().length > 6) linhas.push({ arquivo: it.rel, n, l: l.trim().slice(0, 220) });
  if (new Set(linhas.map((x) => x.arquivo)).size > 1) topicos[t] = linhas.slice(0, 20);
}

// Configuração do fluxo
const padroes = existsSync(join(RAIZ, HW, 'padroes.md')) ? readFileSync(join(RAIZ, HW, 'padroes.md'), 'utf8') : '';
if (padroes.includes('Apague os exemplos abaixo')) achar(null, 'aviso', 'fluxo', `${HW}/padroes.md ainda é o molde: o eixo de padrões revisa contra exemplos. Rode o configurar.`);
const verif = existsSync(join(RAIZ, HW, 'verificacao.json')) ? readFileSync(join(RAIZ, HW, 'verificacao.json'), 'utf8') : '';
if (/tsconfig\.app\.json/.test(verif) && /npx eslint -f json \{arquivos\}/.test(verif)) achar(null, 'aviso', 'fluxo', `${HW}/verificacao.json ainda é o molde de MFE Angular. Rode o configurar.`);
// Lições de uso vencidas: memória que ninguém revalidou vira regra velha.
{
  const cfgL = JSON.parse(JSON.stringify(lerJson(join(RAIZ, HW, 'bchive.json'), {})));
  const pastaL = join(RAIZ, (cfgL.licoes && cfgL.licoes.pasta) || `${String(cfgL.conhecimento || 'conhecimento/').replace(/\/?$/, '/')}licoes`);
  if (existsSync(pastaL)) {
    const hojeL = new Date().toISOString().slice(0, 10);
    const vencidas = readdirSync(pastaL).filter((n) => /^L-.*\.md$/.test(n)).filter((n) => ((readFileSync(join(pastaL, n), 'utf8').match(/^revisar-em:\s*(\S+)/m) || [])[1] || '9999') < hojeL);
    if (vencidas.length) achar(null, 'aviso', 'licoes', `${vencidas.length} lição(ões) de uso vencida(s) (${vencidas.slice(0, 4).join(', ')}): o time confirma ou apaga. node ${HW}/bin/bchive.mjs licoes revisar`);
  }
}
if (usuario) {
  const agentes = itens.filter((it) => it.tipo === 'agente');
  const exec = { ...(lerJson(join(RAIZ, HW, 'executores.json'), { executores: {} }).executores || {}), ...(lerJson(join(RAIZ, ESTADO, 'executores-descobertos.json'), { executores: {} }).executores || {}) };
  for (const nome of Object.keys(exec).filter((n) => !agentesDoFluxo.test(n))) {
    const it = agentes.find((a) => nomeChamavel(a) === nome || nomeChamavel(a).endsWith(`:${nome}`));
    if (!it) { achar(null, 'aviso', 'executor', `executor "${nome}" registrado, mas o agente não foi achado nesta máquina.`); continue; }
    for (const p of conferirExecutor(it)) achar(it, p.nivel, 'executor', `executor "${nome}": ${p.txt}`);
  }
}

// ------------------------------------------------------------------ saída
const hoje = new Date().toISOString().slice(0, 10);
const dir = join(RAIZ, ESTADO, 'auditoria', hoje);
mkdirSync(dir, { recursive: true });
const fixo = itens.filter(sempreCarregado).reduce((a, it) => a + it.tokens, 0);
const ordem = { grave: 0, aviso: 1 };
achados.sort((a, b) => ordem[a.nivel] - ordem[b.nivel]);
const resumo = { em: new Date().toISOString(), usuario, arquivos: itens.length, tokensFixosPorPedido: fixo, graves: achados.filter((a) => a.nivel === 'grave').length, avisos: achados.filter((a) => a.nivel === 'aviso').length };
gravarJson(join(dir, 'achados.json'), { ...resumo, inventario: itens.map(({ rel, tipo, escopo, observacao, tokens, fm }) => ({ rel, tipo, escopo, observacao, tokens, carga: carga({ rel, tipo, escopo, fm }), name: fm?.name || null })), achados, topicos });

const tab = ['| Arquivo | Escopo | Tipo | Carrega | ≈ tokens | Graves | Avisos |', '| --- | --- | --- | --- | ---: | ---: | ---: |'];
for (const it of itens) {
  const a = achados.filter((x) => x.arquivo === it.rel);
  tab.push(`| \`${it.rel}\` | ${it.escopo}${it.observacao ? ` (${it.observacao})` : ''} | ${it.tipo} | ${carga(it)} | ${it.tokens} | ${a.filter((x) => x.nivel === 'grave').length} | ${a.filter((x) => x.nivel === 'aviso').length} |`);
}
writeFileSync(join(dir, 'inventario.md'), [`# Inventário da personalização · ${hoje}`, '', `Custo fixo estimado por pedido (AGENTS.md da raiz, copilot-instructions e instructions com applyTo "**"): ≈${fixo} tokens. Estimativa: caracteres ÷ 4.`, '', ...tab, ''].join('\n'));

// Trechos para julgamento: linhas marcadas com contexto, esqueleto de títulos e regras por tópico. Orçamento fixo.
const ORC = 24000;
const partes = [`# Trechos para julgamento · ${hoje}`, '', 'Gerado por script. Achados mecânicos estão em achados.json; aqui só o que pede leitura humana ou do modelo.', ''];
for (const it of textuais) {
  const marc = achados.filter((x) => x.arquivo === it.rel && x.linha);
  const ls = linhasNumeradas(it.corpo, it.linhaCorpo);
  const titulos = ls.filter(({ l }) => /^#{1,3} /.test(l)).map(({ n, l }) => `${n}: ${l}`).slice(0, 25);
  const regras = ls.filter(({ l }) => /^\s*[-*]\s+\S|^\s*\d+\.\s+\S/.test(l)).length;
  partes.push(`## ${it.rel}`, '', `${it.tipo}, ${it.escopo}, ≈${it.tokens} tokens, ${regras} item(ns) de lista, carrega: ${carga(it)}${it.fm?.description ? `. description: "${String(it.fm.description).slice(0, 200)}"` : ''}`, '');
  if (titulos.length) partes.push('Títulos:', ...titulos.map((t) => `- ${t}`), '');
  // Linha marcada com "→" e as regras dela no fim; uma linha de contexto antes e depois.
  const regrasDa = new Map();
  for (const a of marc.slice(0, 12)) regrasDa.set(a.linha, [...(regrasDa.get(a.linha) || []), a.regra]);
  const mostrar = new Set([...regrasDa.keys()].flatMap((n) => [n - 1, n, n + 1]));
  let anterior = null;
  for (const n of [...mostrar].sort((x, y) => x - y)) {
    const x = ls.find((y) => y.n === n);
    if (!x) continue;
    if (anterior !== null && n > anterior + 1) partes.push('   …');
    const r = regrasDa.get(n);
    partes.push(`${r ? '→' : ' '} ${n}: ${x.l.replace(SEGREDO, (m) => `${m.slice(0, 8)}***`)}${r ? `   [${[...new Set(r)].join(', ')}]` : ''}`);
    anterior = n;
  }
  partes.push('');
  if (partes.join('\n').length > ORC) { partes.push('(orçamento de trechos atingido: os demais arquivos estão só no inventário)'); break; }
}
if (Object.keys(topicos).length && partes.join('\n').length < ORC) {
  partes.push('## Tópicos em mais de um arquivo (possível conflito)', '');
  for (const [t, ls] of Object.entries(topicos)) {
    partes.push(`### ${t}`, ...ls.map((x) => `- ${x.arquivo}:${x.n}: ${x.l}`), '');
    if (partes.join('\n').length > ORC) break;
  }
}
writeFileSync(join(dir, 'trechos.md'), `${partes.join('\n')}\n`);

if (args.includes('--json')) { console.log(JSON.stringify({ ...resumo, achados }, null, 2)); process.exit(0); }
const rel = (n) => barra(join(ESTADO, 'auditoria', hoje, n));
console.log(`Auditoria da personalização · ${itens.length} arquivo(s)${usuario ? ' (repositório, usuário e plugins)' : ' (repositório; --usuario inclui ~/.copilot e plugins)'}`);
console.log(`custo fixo estimado por pedido: ≈${fixo} tokens · ${resumo.graves} grave(s), ${resumo.avisos} aviso(s)`);
for (const a of achados.slice(0, 20)) console.log(`  ${a.nivel === 'grave' ? 'GRAVE' : 'aviso'} ${a.arquivo || '(fluxo)'}${a.linha ? `:${a.linha}` : ''} [${a.regra}] ${a.txt}`);
if (achados.length > 20) console.log(`  ... e mais ${achados.length - 20} em ${rel('achados.json')}`);
console.log(`\ninventário: ${rel('inventario.md')}\ntrechos para julgamento: ${rel('trechos.md')}\nachados: ${rel('achados.json')}`);
