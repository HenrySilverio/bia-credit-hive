## Resumo

Corrige a preparação (`init` e `configurar`) em repositórios fora do padrão, exige Node LTS 22 ou 24 e põe em código o limite do agente de entrada `bchive`, que até agora existia só no texto do agente.

## O que muda

### 1. Preparação em repositórios fora do padrão
- `configurar` não sai mais com erro sem `package.json` na raiz, em Node sem `src/` ou em monolito com o front numa subpasta. Ele propõe camadas por pasta, não propõe comando que não sabe provar e mostra "Sem verificação automática". Ao gravar, tira o molde de MFE do `verificacao.json`.
- Pasta ilegível (presa por outro processo, sem permissão, caminho longo no Windows) não derruba mais o `configurar`, o mapa nem as consultas do agente ao mapa. A lista de arquivos vem do Git.
- Pastas de log fora do Git e do `.gitignore` não travam mais `pacote-revisao`, `gravar-veredito` e `arquivar`. O `init --corrigir` grava em `pastasLocais` do `bchive.json`, que não é versionado, as pastas da raiz fora do Git com 50 ou mais arquivos. O Git e o `.gitignore` do dev não mudam.
- Uma pasta local só vale enquanto o Git não rastreia nada nela. A conferência acontece a cada uso (`git ls-files`) na árvore suja, no mapa e no `configurar`. Pasta que ganhou arquivo versionado (por exemplo, um módulo novo que foi commitado) volta na hora para a revisão, o veredito e o archive. O `init` avisa e, com `--corrigir`, tira essa pasta de `pastasLocais`.
- Arquivo de código solto na raiz (um `main.ts` num repositório sem `src/`) entra na camada `.raiz`, com globs por extensão (`*.ts`). Antes ele ficava fora de toda camada, e uma mudança só nele não rodava verificação nenhuma. O nome começa com ponto porque nenhuma camada de pasta é gerada com ponto, então não colide com pasta real. README, `package.json` e arquivos com ponto na raiz ficam fora.
- Quando um passo falha, o `init` mostra o motivo real (`Error: EPERM…`, "interrompido depois de 4 min") e não a última linha da pilha.

### 2. Node LTS 22 ou 24
- Com Node abaixo de 22, `init` e `configurar` param e os outros comandos avisam. Versão ímpar ou acima de 24 só gera aviso.
- A mensagem aponta para o documento de instalação e configuração no Confluence e pede para fechar e abrir o VS Code se o Node já foi instalado.

### 3. O `bchive` roda o `init.mjs` sem recusar
- Os scripts do fluxo escrevem onde precisam (`.bchive/`, `.git/info/exclude`, hooks locais do mapa). Isso não conta como edição do agente.

### 4. Limites do agente de entrada em código
**Problema.** No GitHub Copilot app, um `/start` com a demanda já descrita fez o `bchive` gerar os arquivos da demanda. Os eventos de uso dessa sessão mostram 15 minutos com buscas, 6 comandos de terminal e 10 escritas no turno principal, sem subagente. Não houve discovery, plano, revisão nem portão humano. O limite "só edita em `.bchive/estado/`" estava só no texto do agente, e o hook não conferia nada disso. A mesma brecha deixava qualquer agente chamar o `bchive-implementador`.

**Correção.**
- **Hook do agente:** o `bchive` ganha um `preToolUse` no frontmatter (`--agente bchive`). Ele:
  - nega edição fora de `.bchive/estado/`. O caminho é lido de qualquer campo de caminho, de listas e de cabeçalho de patch, e não de campo de conteúdo. `..` não escapa da pasta. Escrita sem caminho visível é negada;
  - nega subagente que não seja exatamente o `bchive-gf` deste plugin (`bchive-gf` ou `bia-credit-hive:bchive-gf`). Prefixo (`bchive-gf-x`) e o de outro plugin (`outro:bchive-gf`) não passam. A mesma comparação exata vale para o pacote do revisor e para o `bchive-implementador`;
  - vale também em repositório ainda não preparado;
  - não coleta uso, porque o hook do plugin já registra a mesma ferramenta.
- **Hook do plugin:** o `bchive-implementador` só pode ser chamado numa sessão em que o `bchive-implement` rodou.
- **Sessão:** o `userPromptSubmitted` lê a sessão de novo antes de gravar. Os dois hooks rodam no mesmo evento, e a lista de agentes decide quem pode chamar o executor.
- **Texto:**
  - O agente e a skill `start` dizem que descrever o trabalho não é ordem para fazê-lo.
  - O agente reconhece o comando sem prefixo (`/start`), que é como o Copilot app lista os comandos.
- **Canário:** o `canario conferir` agora diz se o hook do agente rodou no `preToolUse` ("limites do agente de entrada: ativos") e grava `travaEntrada` no `canario.json`.

**Fica de fora (risco aceito).** Escrita pelo terminal, por redirecionamento de shell, não é travada. Fazer isso por padrão de texto seria frágil.

## Como testar
```bash
node testes/smoke.mjs                                # esperado 54/54
```
No Windows, em um repositório real de cada caso:
1. `init`, `configurar` e canário (P3 e Node). Num repositório com pasta local: commitar um arquivo nela, editar e conferir que a árvore suja mostra a edição.
2. No agente `bchive`, no Copilot app e no VS Code:
   - `/start` com a demanda descrita: responde só o próximo passo;
   - "crie o arquivo X": o hook nega com a mensagem do b.IA Credit Hive;
   - canário: mostra "limites do agente de entrada: ativos".
3. No `bchive-implement`, a delegação de uma fatia ao `bchive-implementador` continua funcionando.

Se o canário mostrar o aviso de que o hook do agente não rodou, a ferramenta não dispara o hook do frontmatter no `preToolUse`. Nesse caso os limites do `bchive` voltam a depender só do texto.
