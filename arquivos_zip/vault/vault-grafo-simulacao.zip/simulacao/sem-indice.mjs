// Remove os index.md (menos nenhum) de uma cópia do Vault cheio e roda o checkVault: o custo de "grafo no lugar do índice".
import { cpSync, rmSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const [src, lib] = process.argv.slice(2).map((p) => path.resolve(p));
const { checkVault } = await import(pathToFileURL(path.join(lib, 'vault.mjs')));
const { resolveInPlugin, regularFileAt, walk } = await import(pathToFileURL(path.join(lib, 'fs-utils.mjs')));
for (const modo of ['sem-indices-de-pasta', 'sem-nenhum-indice']) {
  const root = `${src}-${modo}`;
  rmSync(root, { recursive: true, force: true });
  cpSync(src, root, { recursive: true });
  for (const e of walk(root)) if (e.path.endsWith('/index.md') && (modo === 'sem-nenhum-indice' || e.path !== 'vault/index.md')) rmSync(e.abs);
  const f = [];
  const paths = { root, resolve: (r) => resolveInPlugin(root, r), file: (r) => regularFileAt(root, r) };
  const m = JSON.parse(readFileSync(path.join(root, 'plugin.json'), 'utf8'));
  checkVault(paths, walk(root), m, 'plugin.json', (level, code, file) => f.push({ level, code, file }), { skillDirs: new Set([`skills/${m.name}`]), codeOwners: true, org: 'org' });
  const by = {};
  for (const x of f) by[`${x.level} ${x.code}`] = (by[`${x.level} ${x.code}`] ?? 0) + 1;
  console.log(modo, JSON.stringify(by));
}
