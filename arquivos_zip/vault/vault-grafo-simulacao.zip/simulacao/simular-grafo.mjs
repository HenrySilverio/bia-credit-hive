// Simulação reprodutível: Vault de uma tribo no formato OKF 0.2, validado pelo checkVault do catálogo,
// comparando três formas de um agente achar as regras que governam um arquivo de código:
//   A. só índice (leitor genérico, sem busca)
//   B. índice + busca textual (como o Copilot faz com grep)
//   C. grafo montado pelo Hive a partir das notas (um comando, pacote com teto)
// Uso: node simular-grafo.mjs <pasta-saida> [--lib <pasta da lib do catálogo>] [--seed 42]
// Tokens estimados como caracteres / 4 (mesma regra do inventário do Hive).
import { mkdirSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';

const args = process.argv.slice(2);
const out = path.resolve(args[0] ?? 'saida');
const opt = (name, def) => { const i = args.indexOf(name); return i === -1 ? def : args[i + 1]; };
const libDir = path.resolve(opt('--lib', path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'vendor', 'lib')));
const SEED = Number(opt('--seed', 42));

const { checkVault } = await import(pathToFileURL(path.join(libDir, 'vault.mjs')));
const { resolveInPlugin, regularFileAt, walk } = await import(pathToFileURL(path.join(libDir, 'fs-utils.mjs')));
const { parseFrontmatter } = await import(pathToFileURL(path.join(libDir, 'frontmatter.mjs')));

// --- aleatório com semente ---------------------------------------------------------------------------
let s = SEED >>> 0;
const rnd = () => { s = (s + 0x6d2b79f5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const sample = (a, n) => { const c = [...a]; const r = []; while (r.length < n && c.length) r.push(c.splice(Math.floor(rnd() * c.length), 1)[0]); return r; };
const tok = (text) => Math.ceil(text.length / 4);

// --- vocabulário -------------------------------------------------------------------------------------
const SQUADS = ['renegociacao', 'consignado', 'cartao-credito', 'cheque-especial', 'credito-imobiliario', 'veiculos', 'capital-de-giro', 'cobranca'];
const TEMAS = ['elegibilidade', 'simulacao', 'contratacao', 'parcelas', 'limites', 'jornada-digital'];
const TERMOS = ['carencia', 'contrato', 'parcela', 'limite', 'taxa-efetiva', 'prazo', 'garantia', 'inadimplencia', 'score-interno', 'renegociacao', 'portabilidade', 'amortizacao'];
const ARQ_TRIBO = ['camadas-do-front', 'integracao-com-o-legado', 'padrao-de-estado', 'seguranca-logica'];
const TYPES = ['Business Rule', 'Business Rule', 'Business Rule', 'Behavior', 'Behavior', 'Coding Standard', 'Decision', 'Dependency Baseline'];
const FRASES = [
  'O fluxo só avança quando o cliente atende a todas as condições desta seção; qualquer condição falha encerra a etapa com a mensagem de orientação.',
  'A regra vale para pessoa física e jurídica, com o mesmo prazo, e a exceção fica registrada na seção de perguntas em aberto.',
  'O componente de tela nunca calcula valores: ele recebe o resultado pronto da camada de domínio e só decide o que mostrar.',
  'Quando o serviço de origem não responde, a jornada mostra o estado de indisponibilidade e oferece tentar de novo, sem perder o que foi preenchido.',
  'O prazo conta em dias corridos a partir da data de assinatura do contrato, e não da data da primeira parcela.',
  'A validação acontece duas vezes: na tela, para orientar o cliente, e no serviço, que é a fonte da verdade.',
  'Uma alteração nesta regra exige revisão do PO e do especialista de negócio, porque muda o que o cliente vê na simulação.',
  'O estado da jornada fica no store da feature; os componentes só leem sinais e disparam ações nomeadas.',
  'A mensagem exibida ao cliente vem do catálogo de textos da squad, nunca escrita direto no componente.',
  'O limite disponível é recalculado a cada nova simulação, e o valor anterior não é reaproveitado.',
  'Os testes de comportamento descrevem os três caminhos principais: aprovado, recusado e pendente de análise.',
  'A integração com o sistema legado passa sempre pela camada de adaptação, que traduz os códigos de retorno em estados do domínio.',
];
const titulo = (slug) => slug.replace(/-/g, ' ').replace(/^./, (c) => c.toUpperCase());

// --- geração do Vault ----------------------------------------------------------------------------------
function gerarVault(root, { squads, notasPorTema }) {
  rmSync(root, { recursive: true, force: true });
  const files = new Map();
  const put = (rel, text) => files.set(rel, text);
  const name = 'credito-tribo-vault';
  put('plugin.json', JSON.stringify({ $schema: 'https://agent-plugins.org/schemas/1.0.0/plugin.schema.json', name, version: '0.1.0', description: 'Conhecimento da tribo de crédito.', author: { name: 'Tribo Crédito' }, keywords: ['knowledge-vault'], extensions: { 'br.com.bradesco.vault': { format: 'okf' } } }, null, 2));
  put(`skills/${name}/SKILL.md`, `---\nname: ${name}\ndescription: Lê o vault da tribo de crédito.\n---\n\nLeia vault/index.md primeiro.\n`);
  put('.github/CODEOWNERS', '* @org/tribo-credito\n/skills/ @org/reusable-ai-keepers\n/.github/CODEOWNERS @org/reusable-ai-keepers\n');
  put('README.md', '# Vault da tribo de crédito\n');

  const notes = []; // { rel, type, title, description, sources:[file], links:[rel], squad, tema }
  const fm = (n) => {
    const src = n.sources.map((f, i) => `  - id: fonte-${i + 1}\n    resource: ${f}#L${10 + i * 30}-L${30 + i * 30}\n    last_modified: 2026-10-${String(10 + i).padStart(2, '0')}`).join('\n');
    return `---\ntype: ${n.type}\ntitle: ${JSON.stringify(n.title)}\ndescription: ${JSON.stringify(n.description)}\ntags: [${n.squad ?? 'tribo'}, ${n.tema ?? 'geral'}]\nstatus: draft\ngenerated: { by: "agent:bia-credit-hive/vault-extractor", at: 2026-11-27T12:00:00Z }\nsources:\n${src || '  - id: fonte-1\n    resource: ata do refinamento de 20/11, PM da tribo'}\nstale_after: 2027-05-27\nbchive: { repo: ${n.repo ?? 'tribo'}, commit: 3f2a9c1 }\n---\n`;
  };
  const rel = (from, to) => path.posix.relative(path.posix.dirname(from), to);

  // tribo: glossário único com seções e notas de arquitetura
  const glossRel = 'vault/tribo/glossario.md';
  const arqRels = ARQ_TRIBO.map((a) => `vault/tribo/${a}.md`);
  notes.push({ rel: glossRel, type: 'Glossary', title: 'Glossário da tribo de crédito', description: 'Termos do domínio de crédito usados por todas as squads da tribo.', sources: [], links: [], tribo: true });
  for (const r of arqRels) notes.push({ rel: r, type: 'Architecture', title: titulo(path.posix.basename(r, '.md')), description: `Regra de arquitetura da tribo: ${path.posix.basename(r, '.md').replace(/-/g, ' ')}.`, sources: [], links: [glossRel], tribo: true });

  for (const sq of SQUADS.slice(0, squads)) {
    const repos = [`${sq}-web`, `${sq}-bff`];
    for (const tema of TEMAS) {
      const pool = Array.from({ length: 12 }, (_, i) => `${pick(repos)}/src/app/${tema}/${tema}-${i + 1}.${pick(['service', 'store', 'component', 'rules'])}.ts`);
      const archRel = `vault/squads/${sq}/${tema}/arquitetura-de-${tema}.md`;
      const temaNotes = [{ rel: archRel, type: 'Architecture', title: `Arquitetura de ${tema.replace(/-/g, ' ')}`, description: `Camadas e dependências permitidas em ${tema.replace(/-/g, ' ')} da squad ${sq}.`, sources: sample(pool, 2), links: [sample(arqRels, 1)[0], glossRel], squad: sq, tema, repo: repos[0] }];
      for (let i = 1; i < notasPorTema; i += 1) {
        const type = pick(TYPES);
        const slug = `${tema}-regra-${String(i).padStart(2, '0')}`;
        temaNotes.push({ rel: `vault/squads/${sq}/${tema}/${slug}.md`, type, title: `${titulo(tema)}: ${type === 'Decision' ? 'decisão' : 'regra'} ${i}`, description: `${type} sobre ${tema.replace(/-/g, ' ')} na squad ${sq}, com limites, exceções e comportamento esperado.`, sources: sample(pool, 2 + Math.floor(rnd() * 2)), links: [archRel, glossRel], squad: sq, tema, repo: pick(repos) });
      }
      for (const n of temaNotes.slice(1)) { const peer = pick(temaNotes.slice(1)); if (peer !== n) n.links.push(peer.rel); }
      notes.push(...temaNotes);
    }
  }

  // corpo das notas: ~3.500 caracteres, rodapé por afirmação, links relativos
  for (const n of notes) {
    const linkLines = n.links.map((l) => `- [${titulo(path.posix.basename(l, '.md'))}](${rel(n.rel, l)}${l === glossRel ? `#${pick(TERMOS)}` : ''})`).join('\n');
    const paras = Array.from({ length: 6 }, (_, k) => `${sample(FRASES, 3).join(' ')}${n.sources.length ? `[^fonte-${(k % n.sources.length) + 1}]` : ''}`);
    const foot = n.sources.map((f, i) => `[^fonte-${i + 1}]: ${f}`).join('\n');
    let body = `# ${n.title}\n\n${paras[0]}\n\n## Regra\n\n${paras[1]}\n\n${paras[2]}\n\n## Comportamento\n\n${paras[3]}\n\n${paras[4]}\n\n## Perguntas em aberto\n\n${paras[5]}\n\n## Relacionadas\n\n${linkLines}\n`;
    if (n.rel === glossRel) body = `# ${n.title}\n\n${TERMOS.map((t) => `## ${t}\n\n${sample(FRASES, 2).join(' ')}`).join('\n\n')}\n`;
    if (foot) body += `\n${foot}\n`;
    put(n.rel, fm(n) + '\n' + body);
  }

  // índices: um por pasta com notas, mais raiz, squads/ e cada squad
  const byDir = new Map();
  for (const n of notes) { const d = path.posix.dirname(n.rel); if (!byDir.has(d)) byDir.set(d, []); byDir.get(d).push(n); }
  for (const [dir, list] of byDir) put(`${dir}/index.md`, `# Notes\n\n${list.map((n) => `- [${n.title}](${path.posix.basename(n.rel)}): ${n.description}`).join('\n')}\n`);
  const squadList = SQUADS.slice(0, squads);
  for (const sq of squadList) put(`vault/squads/${sq}/index.md`, `# Notes\n\n${TEMAS.map((t) => `- [${titulo(t)}](${t}/index.md): regras, comportamento e decisões de ${t.replace(/-/g, ' ')} da squad ${sq}.`).join('\n')}\n`);
  put('vault/squads/index.md', `# Notes\n\n${squadList.map((sq) => `- [${titulo(sq)}](${sq}/index.md): conhecimento da squad ${sq}.`).join('\n')}\n`);
  put('vault/index.md', `---\nokf_version: "0.2"\n---\n\n# Notes\n\n- [Tribo](tribo/index.md): glossário e arquitetura comum da tribo.\n- [Squads](squads/index.md): uma pasta por squad.\n`);
  put('vault/log.md', '# Log\n\n## 2026-11-27\n\n**Update** Primeira carga gerada pelo extrator do Hive.\n');

  for (const [r, text] of files) { const abs = path.join(root, r); mkdirSync(path.dirname(abs), { recursive: true }); writeFileSync(abs, text); }
  return { files, notes };
}

// --- validação com o código do catálogo --------------------------------------------------------------------
function validar(root) {
  const findings = [];
  const add = (level, code, file, message) => findings.push({ level, code, file, message });
  const paths = { root, resolve: (r) => resolveInPlugin(root, r), file: (r) => regularFileAt(root, r) };
  const manifest = JSON.parse(readFileSync(path.join(root, 'plugin.json'), 'utf8'));
  const tree = walk(root);
  const skillDirs = new Set([`skills/${manifest.name}`]);
  const t0 = performance.now();
  checkVault(paths, tree, manifest, 'plugin.json', add, { skillDirs, codeOwners: true, org: 'org' });
  return { findings, ms: performance.now() - t0 };
}

// --- grafo montado pelo Hive a partir das notas -------------------------------------------------------------
function montarGrafo(files) {
  const t0 = performance.now();
  const nodes = {}; const edges = []; const byFile = new Map();
  for (const [r, text] of files) {
    if (!r.startsWith('vault/') || !r.endsWith('.md') || /\/(index|log)\.md$/.test(r)) continue;
    const f = parseFrontmatter(text);
    const d = f.data ?? {};
    nodes[r] = { type: d.type, title: d.title, description: d.description, status: d.status ?? 'stable', tier: Array.isArray(d.verified) && d.verified.some((v) => String(v.by).startsWith('human:')) ? 'human' : d.verified ? 'machine' : 'unverified', stale_after: String(d.stale_after ?? ''), tokens: tok(f.body) };
    for (const src of d.sources ?? []) {
      const file = String(src.resource ?? '').split('#')[0];
      if (!file.includes('/') || /\s/.test(file)) continue;
      if (!byFile.has(file)) byFile.set(file, new Set());
      byFile.get(file).add(r);
    }
    for (const m of f.body.matchAll(/\]\(([^)#\s]+)(?:#[^)]*)?\)/g)) {
      if (/^[a-z]+:/i.test(m[1])) continue;
      edges.push([r, path.posix.normalize(path.posix.join(path.posix.dirname(r), m[1]))]);
    }
  }
  const grafo = { versao: 1, nodes, edges, byFile: Object.fromEntries([...byFile].map(([k, v]) => [k, [...v]])) };
  return { grafo, ms: performance.now() - t0 };
}

// --- as três formas de consulta ------------------------------------------------------------------------------
function consultar(files, notes, grafo, alvo) {
  const direct = grafo.byFile[alvo] ?? [];
  const related = [...new Set(grafo.edges.filter(([a]) => direct.includes(a)).map(([, b]) => b))].filter((b) => !direct.includes(b) && grafo.nodes[b]);
  const full = (r) => { if (!files.has(r)) throw new Error("sem arquivo " + r); return tok(files.get(r)); };
  const sq = notes.find((n) => n.rel === direct[0])?.squad;

  // A. só índice: raiz → squads → squad → índices de tema da squad; abre notas da squad em ordem aleatória até achar
  //    todas as diretas (o índice não diz qual nota cita qual arquivo); depois abre as relacionadas pelos links.
  const temaIdx = TEMAS.map((t) => `vault/squads/${sq}/${t}/index.md`);
  const idxA = ['vault/index.md', 'vault/squads/index.md', `vault/squads/${sq}/index.md`, ...temaIdx];
  const squadNotes = sample(notes.filter((n) => n.squad === sq).map((n) => n.rel), Infinity);
  const need = new Set(direct); const openedA = [];
  for (const r of squadNotes) { if (!need.size) break; openedA.push(r); need.delete(r); }
  const tA = idxA.reduce((a, r) => a + full(r), 0) + openedA.reduce((a, r) => a + full(r), 0) + related.reduce((a, r) => a + full(r), 0);
  const cA = idxA.length + openedA.length + related.length;

  // B. índice + busca: uma busca pelo caminho (linhas encontradas), abre as diretas e as relacionadas por inteiro.
  const grepOut = direct.map((r) => `${r}:    resource: ${alvo}#L10-L30`).join('\n');
  const tB = tok(grepOut) + direct.reduce((a, r) => a + full(r), 0) + related.reduce((a, r) => a + full(r), 0);
  const cB = 1 + direct.length + related.length;

  // C. grafo: um comando; diretas com o corpo, relacionadas só com tipo, título, descrição e nível de confiança.
  const pack = [
    ...direct.map((r) => `## ${grafo.nodes[r].title} (${grafo.nodes[r].type}, ${grafo.nodes[r].tier}, ${grafo.nodes[r].status})\n${parseFrontmatter(files.get(r)).body}`),
    ...related.map((r) => `- ${grafo.nodes[r].title} (${grafo.nodes[r].type}, ${grafo.nodes[r].tier}): ${grafo.nodes[r].description} → ${r}`),
  ].join('\n');
  const tC = tok(pack) + 60;
  return { direct: direct.length, related: related.length, A: { t: tA, c: cA }, B: { t: tB, c: cB }, C: { t: tC, c: 1 } };
}

const stat = (xs) => { const a = [...xs].sort((x, y) => x - y); const q = (p) => a[Math.min(a.length - 1, Math.floor(p * a.length))]; return { mediana: q(0.5), p90: q(0.9), min: a[0], max: a.at(-1) }; };

// --- cenários ------------------------------------------------------------------------------------------------
const cenarios = [
  { nome: 'inicio', squads: 2, notasPorTema: 5 },
  { nome: 'metade', squads: 4, notasPorTema: 18 },
  { nome: 'cheio', squads: 8, notasPorTema: 18 },
];
const resultado = { seed: SEED, regraTokens: 'caracteres / 4', cenarios: [] };
for (const c of cenarios) {
  const root = path.join(out, `vault-${c.nome}`);
  const { files, notes } = gerarVault(root, c);
  const v = validar(root);
  const { grafo, ms } = montarGrafo(files);
  const grafoJson = JSON.stringify(grafo);
  const alvos = Object.keys(grafo.byFile);
  const qs = sample(alvos, 200).map((a) => consultar(files, notes, grafo, a));
  const vaultFiles = [...files.keys()].filter((r) => r.startsWith('vault/'));
  const idxFiles = vaultFiles.filter((r) => r.endsWith('/index.md'));
  const r = {
    ...c,
    arquivosVault: vaultFiles.length,
    notas: vaultFiles.filter((x) => !/\/(index|log)\.md$/.test(x)).length,
    indices: idxFiles.length,
    tokensTodosIndices: idxFiles.reduce((a, x) => a + tok(files.get(x)), 0),
    validador: { erros: v.findings.filter((f) => f.level === 'error').length, avisos: v.findings.filter((f) => f.level === 'warning').length, ms: Math.round(v.ms), amostra: v.findings.slice(0, 5) },
    grafo: { ms: Math.round(ms), kb: Math.round(Buffer.byteLength(grafoJson) / 1024), tokensSeLidoInteiro: tok(grafoJson), nos: Object.keys(grafo.nodes).length, arestas: grafo.edges.length },
    consulta: {
      diretas: stat(qs.map((q) => q.direct)), relacionadas: stat(qs.map((q) => q.related)),
      A: { tokens: stat(qs.map((q) => q.A.t)), chamadas: stat(qs.map((q) => q.A.c)) },
      B: { tokens: stat(qs.map((q) => q.B.t)), chamadas: stat(qs.map((q) => q.B.c)) },
      C: { tokens: stat(qs.map((q) => q.C.t)), chamadas: stat(qs.map((q) => q.C.c)) },
    },
  };
  resultado.cenarios.push(r);
  if (c.nome === 'cheio') writeFileSync(path.join(out, 'grafo-cheio.json'), grafoJson);
}
writeFileSync(path.join(out, 'resultado.json'), JSON.stringify(resultado, null, 2));
console.log(JSON.stringify(resultado, (k, v) => (k === 'amostra' ? undefined : v), 1));
